bl_info = {
    "name": "Astro Pipeline 0.21",
    "author": "ChatGPT + Jon",
    "version": (0, 21, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Astro",
    "description": "PMBOK-style character pipeline with animation baking, manual mapping overrides, preview conversion, validation, GLB export, diagnostics, and export tools for Astro MOBA.",
    "category": "Rigging",
}

import bpy
from importlib import reload

from . import constants
from . import utils
from . import rig
from . import sockets
from . import poses
from . import locomotion
from . import diagnostics
from . import converter
from . import export
from . import settings
from . import ui

MODULES = [
    rig,
    sockets,
    poses,
    locomotion,
    diagnostics,
    converter,
    export,
    settings,
    ui,
]

CLASSES = []
for module in MODULES:
    CLASSES.extend(getattr(module, "classes", ()))

def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.astro_moba_settings = bpy.props.PointerProperty(type=settings.ASTRO_Settings)

def unregister():
    if hasattr(bpy.types.Scene, "astro_moba_settings"):
        del bpy.types.Scene.astro_moba_settings

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
