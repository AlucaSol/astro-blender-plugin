import bpy
import math
from mathutils import Euler
from .constants import POSE_TEXT_PREFIX
from .utils import get_armature
from .poses import apply_saved_pose


def get_animation_target_armature(context):
    """Prefer the configured/preview armature for animation baking."""
    settings = context.scene.astro_moba_settings

    configured = bpy.data.objects.get(settings.bake_target_armature)
    if configured and configured.type == "ARMATURE":
        return configured

    preview = bpy.data.objects.get("Armature_Preview")
    if preview and preview.type == "ARMATURE":
        return preview

    active = bpy.context.object
    if active and active.type == "ARMATURE":
        return active

    return get_armature()


def set_pose_bone_worldish_rotation(arm, bone_name, x=0, y=0, z=0):
    pb = arm.pose.bones.get(bone_name)
    if not pb:
        return

    pb.rotation_mode = "QUATERNION"
    rest_q = pb.bone.matrix_local.to_quaternion()
    desired_q = Euler((math.radians(x), math.radians(y), math.radians(z)), "XYZ").to_quaternion()
    local_q = rest_q.inverted() @ desired_q @ rest_q
    pb.rotation_quaternion = local_q

def save_key(pb, frame):
    pb.keyframe_insert(data_path="location", frame=frame)
    pb.keyframe_insert(data_path="rotation_quaternion", frame=frame)
    pb.keyframe_insert(data_path="scale", frame=frame)

def key_bones(arm, bone_names, frame):
    for bone_name in bone_names:
        pb = arm.pose.bones.get(bone_name)
        if pb:
            pb.rotation_mode = "QUATERNION"
            save_key(pb, frame)

def create_locomotion_action(context, movement_name, action_name, frame_end, stride, bob, bob_axis, torso_twist, lean, speed_scale, base_pose_name, target_armature=None, fake_user=True):
    arm = target_armature or get_animation_target_armature(context)
    if not arm:
        raise Exception("No armature found")

    pose_text_name = POSE_TEXT_PREFIX + base_pose_name
    if not bpy.data.texts.get(pose_text_name):
        raise Exception(f"Missing saved pose: {pose_text_name}")

    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = frame_end

    if action_name in bpy.data.actions:
        bpy.data.actions.remove(bpy.data.actions[action_name])

    action = bpy.data.actions.new(action_name)
    action.use_fake_user = fake_user
    arm.animation_data_create()
    arm.animation_data.action = action

    bpy.context.view_layer.objects.active = arm
    arm.select_set(True)
    bpy.ops.object.mode_set(mode="POSE")

    bones_to_key = [
        "Pelvis", "Spine1", "Spine2", "Ribcage", "Neck", "Head",
        "LThigh", "LCalf", "LFoot", "RThigh", "RCalf", "RFoot",
        "LCollarbone", "LUpperarm", "LForearm", "LPalm",
        "RCollarbone", "RUpperarm", "RForearm", "RPalm",
    ]

    contact_a = 1
    passing_a = max(2, int(frame_end * 0.25))
    contact_b = max(3, int(frame_end * 0.50))
    passing_b = max(4, int(frame_end * 0.75))
    loop_frame = frame_end + 1

    def set_frame_pose(frame, phase):
        scene.frame_set(frame)
        apply_saved_pose(arm, pose_text_name)

        if phase == "contact_a":
            pelvis_z = -torso_twist
            left_thigh = -stride
            right_thigh = stride * 0.85
            left_calf = stride * 1.25
            right_calf = stride * 0.45
            left_foot = -stride * 0.25
            right_foot = stride * 0.25
            bob_y = 0.0
            spine_twist = torso_twist * 0.45
        elif phase == "passing_a":
            pelvis_z = 0
            left_thigh = stride * 0.05
            right_thigh = -stride * 0.15
            left_calf = stride * 0.60
            right_calf = stride * 1.10
            left_foot = 0
            right_foot = -stride * 0.15
            bob_y = bob
            spine_twist = 0
        elif phase == "contact_b":
            pelvis_z = torso_twist
            left_thigh = stride * 0.85
            right_thigh = -stride
            left_calf = stride * 0.45
            right_calf = stride * 1.25
            left_foot = stride * 0.25
            right_foot = -stride * 0.25
            bob_y = 0.0
            spine_twist = -torso_twist * 0.45
        else:
            pelvis_z = 0
            left_thigh = -stride * 0.15
            right_thigh = stride * 0.05
            left_calf = stride * 1.10
            right_calf = stride * 0.60
            left_foot = -stride * 0.15
            right_foot = 0
            bob_y = bob
            spine_twist = 0

        pelvis = arm.pose.bones.get("Pelvis")
        if pelvis:
            pelvis.rotation_mode = "QUATERNION"
            pelvis.location = (0, 0, 0)
            bob_amount = bob_y * 0.025
            if bob_axis == "X":
                pelvis.location.x = bob_amount
            elif bob_axis == "Y":
                pelvis.location.y = bob_amount
            else:
                pelvis.location.z = bob_amount

        set_pose_bone_worldish_rotation(arm, "Pelvis", 0, 0, pelvis_z)
        set_pose_bone_worldish_rotation(arm, "Spine1", -lean, 0, spine_twist)
        set_pose_bone_worldish_rotation(arm, "Spine2", -lean * 0.65, 0, spine_twist * 0.75)
        set_pose_bone_worldish_rotation(arm, "Ribcage", -lean * 0.45, 0, spine_twist * 0.55)
        set_pose_bone_worldish_rotation(arm, "Head", lean * 0.65, 0, 0)

        set_pose_bone_worldish_rotation(arm, "LThigh", left_thigh, 0, 0)
        set_pose_bone_worldish_rotation(arm, "LCalf", left_calf, 0, 0)
        set_pose_bone_worldish_rotation(arm, "LFoot", left_foot, 0, 0)
        set_pose_bone_worldish_rotation(arm, "RThigh", right_thigh, 0, 0)
        set_pose_bone_worldish_rotation(arm, "RCalf", right_calf, 0, 0)
        set_pose_bone_worldish_rotation(arm, "RFoot", right_foot, 0, 0)

        key_bones(arm, bones_to_key, frame)

    set_frame_pose(contact_a, "contact_a")
    set_frame_pose(passing_a, "passing_a")
    set_frame_pose(contact_b, "contact_b")
    set_frame_pose(passing_b, "passing_b")
    set_frame_pose(loop_frame, "contact_a")

    if hasattr(action, "fcurves"):
        for fc in action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = "BEZIER"

    scene.frame_start = 1
    scene.frame_end = frame_end
    scene.frame_set(1)
    bpy.ops.object.mode_set(mode="OBJECT")
    return action_name

def generate_selected_locomotion(context, action_name_override=None, target_armature=None):
    settings = context.scene.astro_moba_settings

    if settings.base_pose_enum == "NONE":
        raise Exception("No saved base pose selected")

    movement = settings.movement_type
    base_pose = settings.base_pose_enum
    action_suffix = base_pose

    if movement == "WALK":
        return create_locomotion_action(
            context, "Walk", (action_name_override or ("Walk_" + action_suffix)), 32,
            settings.stride_length * 0.55,
            settings.vertical_bob * 0.55,
            settings.bob_axis,
            settings.torso_twist * 0.75,
            settings.forward_lean * 0.45,
            settings.speed_scale,
            base_pose,
            target_armature=target_armature,
        )

    if movement == "SPRINT":
        return create_locomotion_action(
            context, "Sprint", (action_name_override or ("Sprint_" + action_suffix)), 20,
            settings.stride_length * 1.2,
            settings.vertical_bob * 1.15,
            settings.bob_axis,
            settings.torso_twist * 1.15,
            settings.forward_lean * 1.35,
            settings.speed_scale,
            base_pose,
            target_armature=target_armature,
        )

    return create_locomotion_action(
        context, "Run", (action_name_override or ("Run_" + action_suffix)), 24,
        settings.stride_length,
        settings.vertical_bob,
        settings.bob_axis,
        settings.torso_twist,
        settings.forward_lean,
        settings.speed_scale,
        base_pose,
    )

def refresh_locomotion_preview(self, context):
    settings = context.scene.astro_moba_settings
    if not settings.live_preview:
        return
    if settings.base_pose_enum == "NONE":
        return
    try:
        generate_selected_locomotion(context)
    except Exception as e:
        print(f"Astro MOBA live preview skipped: {e}")

class ASTRO_OT_generate_locomotion(bpy.types.Operator):
    bl_idname = "astro_moba.generate_locomotion"
    bl_label = "Generate Selected Movement"
    bl_description = "Generate the selected walk/run/sprint cycle using the selected base pose"

    def execute(self, context):
        try:
            action_name = generate_selected_locomotion(context)
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}

        self.report({"INFO"}, f"Generated {action_name}")
        return {"FINISHED"}

class ASTRO_OT_reset_locomotion_defaults(bpy.types.Operator):
    bl_idname = "astro_moba.reset_locomotion_defaults"
    bl_label = "Reset Slider Defaults"
    bl_description = "Reset locomotion generator sliders to the recommended default run settings"

    def execute(self, context):
        settings = context.scene.astro_moba_settings
        old_preview = settings.live_preview
        settings.live_preview = False
        settings.movement_type = "RUN"
        settings.stride_length = 28.0
        settings.vertical_bob = 8.0
        settings.bob_axis = "Z"
        settings.torso_twist = 4.0
        settings.forward_lean = 8.0
        settings.speed_scale = 1.0
        settings.live_preview = old_preview
        self.report({"INFO"}, "Locomotion defaults restored")
        return {"FINISHED"}


class ASTRO_OT_bake_locomotion_action(bpy.types.Operator):
    bl_idname = "astro_moba.bake_locomotion_action"
    bl_label = "Bake Action"
    bl_description = "Bake the current locomotion generator settings into a real Blender Action for export"

    def execute(self, context):
        settings = context.scene.astro_moba_settings
        lines = ["========== ASTRO MOBA BAKE ACTION ==========", ""]

        target_arm = get_animation_target_armature(context)

        if not target_arm:
            lines.append("ERROR: No target armature found.")
            lines.append("Expected Armature_Preview or another configured armature.")
            from .utils import write_text_report
            write_text_report("ASTRO_BAKE_ACTION_REPORT", lines)
            self.report({"ERROR"}, "No target armature found")
            return {"CANCELLED"}

        if settings.base_pose_enum == "NONE":
            lines.append("ERROR: No saved base pose selected.")
            from .utils import write_text_report
            write_text_report("ASTRO_BAKE_ACTION_REPORT", lines)
            self.report({"ERROR"}, "No saved base pose selected")
            return {"CANCELLED"}

        action_name = settings.bake_action_name.strip()
        if not action_name:
            action_name = f"{settings.movement_type.title()}_{settings.base_pose_enum}"

        try:
            baked_action_name = generate_selected_locomotion(
                context,
                action_name_override=action_name,
                target_armature=target_arm,
            )
        except Exception as e:
            lines.append(f"ERROR: Bake failed: {e}")
            from .utils import write_text_report
            write_text_report("ASTRO_BAKE_ACTION_REPORT", lines)
            self.report({"ERROR"}, f"Bake failed: {e}")
            return {"CANCELLED"}

        action = bpy.data.actions.get(baked_action_name)
        fcurve_count = len(action.fcurves) if action and hasattr(action, "fcurves") else 0
        frame_range = tuple(round(v, 3) for v in action.frame_range) if action and hasattr(action, "frame_range") else "Unavailable"

        lines.append(f"Target armature: {target_arm.name}")
        lines.append(f"Base pose: {settings.base_pose_enum}")
        lines.append(f"Movement type: {settings.movement_type}")
        lines.append(f"Baked action: {baked_action_name}")
        lines.append(f"Fake user enabled: {action.use_fake_user if action else 'Unknown'}")
        lines.append(f"F-curves: {fcurve_count}")
        lines.append(f"Frame range: {frame_range}")
        lines.append("")
        lines.append("Generator settings:")
        lines.append(f"  Stride Length: {settings.stride_length}")
        lines.append(f"  Vertical Bob: {settings.vertical_bob}")
        lines.append(f"  Bob Axis: {settings.bob_axis}")
        lines.append(f"  Torso Twist: {settings.torso_twist}")
        lines.append(f"  Forward Lean: {settings.forward_lean}")
        lines.append(f"  Speed Scale: {settings.speed_scale}")
        lines.append("")
        lines.append("Next steps:")
        lines.append("  1. Run Validate Preview Scene.")
        lines.append("  2. Export Preview GLB.")
        lines.append("  3. Import into Godot and look for this action in AnimationPlayer.")
        lines.append("")
        lines.append("========== END BAKE ACTION ==========")

        from .utils import write_text_report
        write_text_report("ASTRO_BAKE_ACTION_REPORT", lines)
        self.report({"INFO"}, f"Baked action: {baked_action_name}")
        return {"FINISHED"}


class ASTRO_OT_animation_action_report(bpy.types.Operator):
    bl_idname = "astro_moba.animation_action_report"
    bl_label = "Action Report"
    bl_description = "List all Blender Actions currently available for export"

    def execute(self, context):
        from .utils import write_text_report
        lines = ["========== ASTRO MOBA ACTION REPORT ==========", ""]

        if not bpy.data.actions:
            lines.append("No actions found.")
        else:
            for action in bpy.data.actions:
                fcurve_count = len(action.fcurves) if hasattr(action, "fcurves") else "Unavailable"
                frame_range = tuple(round(v, 3) for v in action.frame_range) if hasattr(action, "frame_range") else "Unavailable"
                users = action.users
                fake_user = action.use_fake_user
                lines.append(f"- {action.name}")
                lines.append(f"    F-curves: {fcurve_count}")
                lines.append(f"    Frame range: {frame_range}")
                lines.append(f"    Users: {users}")
                lines.append(f"    Fake user: {fake_user}")

        lines.append("")
        lines.append("========== END ACTION REPORT ==========")
        write_text_report("ASTRO_ACTION_REPORT", lines)
        self.report({"INFO"}, "Action report created")
        return {"FINISHED"}

classes = (
    ASTRO_OT_generate_locomotion,
    ASTRO_OT_reset_locomotion_defaults,
    ASTRO_OT_bake_locomotion_action,
    ASTRO_OT_animation_action_report,
)
