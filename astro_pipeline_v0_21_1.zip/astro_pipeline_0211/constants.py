from mathutils import Vector

ARMATURE_NAME = "Armature"
POSE_TEXT_PREFIX = "ASTRO_POSE_"

REQUIRED_BONES = [
    "Pelvis", "Spine1", "Spine2", "Ribcage", "Neck", "Head",
    "LThigh", "LCalf", "LFoot", "RThigh", "RCalf", "RFoot",
    "LCollarbone", "LUpperarm", "LForearm", "LPalm",
    "RCollarbone", "RUpperarm", "RForearm", "RPalm",
]

SOCKETS = [
    ("WeaponSocket", "RPalm", Vector((0.00, -0.08, 0.00))),
    ("LeftWeaponSocket", "LPalm", Vector((0.00, -0.08, 0.00))),
    ("ShieldSocket", "LPalm", Vector((0.00, -0.12, 0.00))),
    ("BeltSocket_L", "Pelvis", Vector((-0.18, 0.00, -0.10))),
    ("BeltSocket_R", "Pelvis", Vector((0.18, 0.00, -0.10))),
    ("BackpackSocket", "Spine2", Vector((0.00, 0.18, 0.00))),
    ("ChestSocket", "Ribcage", Vector((0.00, -0.14, 0.05))),
    ("HeadSocket", "Head", Vector((0.00, 0.00, 0.18))),
]

STANDARD_RENAME_MAP = {
    "RArmCollarbone": "RCollarbone",
    "RArmUpperarm": "RUpperarm",
    "RArmForearm": "RForearm",
    "RArmPalm": "RPalm",
    "PalmBone001": "LPalmBone1",
    "PalmBone002": "LPalmBone2",
    "PalmBone001.001": "RPalmBone1",
    "PalmBone002.001": "RPalmBone2",
}
