import bpy

class ASTRO_PT_tools_panel(bpy.types.Panel):
    bl_label = "Astro Pipeline"
    bl_idname = "ASTRO_PT_tools_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Astro"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.astro_moba_settings

        box = layout.box()
        box.label(text="1. Analyze")
        box.operator("astro_moba.classify_asset", icon="VIEWZOOM")
        box.operator("astro_moba.analyze_character", icon="TEXT")
        box.operator("astro_moba.conversion_readiness", icon="CHECKMARK")
        box.operator("astro_moba.bind_pose_inspector", icon="BONE_DATA")

        box = layout.box()
        box.label(text="2. Convert")
        box.operator("astro_moba.prepare_conversion", icon="DUPLICATE")
        box.operator("astro_moba.map_rigid_accessories", icon="OUTLINER_OB_GROUP_INSTANCE")
        box.operator("astro_moba.preview_conversion", icon="HIDE_OFF")
        box.separator()
        box.label(text="Manual Mapping")
        box.prop(settings, "manual_mapping_target")
        box.operator("astro_moba.apply_manual_mapping", icon="CONSTRAINT_BONE")
        box.operator("astro_moba.manual_mapping_report", icon="TEXT")
        box.separator()
        box.operator("astro_moba.convert_duplicate_scale", icon="FULLSCREEN_ENTER")
        box.operator("astro_moba.rebuild_astro_rig", icon="ARMATURE_DATA")

        box = layout.box()
        box.label(text="3. Rig & Sockets")
        box.operator("astro_moba.validate_rig", icon="CHECKMARK")
        box.operator("astro_moba.rename_standard_bones", icon="SORTALPHA")
        box.operator("astro_moba.create_sockets", icon="BONE_DATA")
        box.operator("astro_moba.socket_report", icon="TEXT")
        box.operator("astro_moba.center_weapon_socket", icon="EMPTY_ARROWS")
        box.operator("astro_moba.center_belt_sockets", icon="EMPTY_ARROWS")

        box = layout.box()
        box.label(text="4. Validate")
        box.operator("astro_moba.validate_preview_scene", icon="CHECKMARK")

        box = layout.box()
        box.label(text="5. Animation Authoring")
        box.operator("astro_moba.reset_pose", icon="LOOP_BACK")
        box.operator("astro_moba.save_current_pose", icon="FILE_TICK")
        box.operator("astro_moba.load_pose", icon="FILE_REFRESH")

        box.separator()
        box.label(text="Animation Generator")
        box.prop(settings, "base_pose_enum")
        box.prop(settings, "movement_type")
        box.prop(settings, "live_preview")
        box.prop(settings, "stride_length", slider=True)
        box.prop(settings, "vertical_bob", slider=True)
        box.prop(settings, "bob_axis")
        box.prop(settings, "torso_twist", slider=True)
        box.prop(settings, "forward_lean", slider=True)
        box.prop(settings, "speed_scale", slider=True)
        box.operator("astro_moba.generate_locomotion", icon="ARMATURE_DATA")
        box.operator("astro_moba.reset_locomotion_defaults", icon="LOOP_BACK")
        box.separator()
        box.label(text="Bake for Export")
        box.prop(settings, "bake_target_armature")
        box.prop(settings, "bake_action_name")
        box.operator("astro_moba.bake_locomotion_action", icon="ACTION")
        box.operator("astro_moba.animation_action_report", icon="TEXT")

        box = layout.box()
        box.label(text="6. Export")
        box.prop(settings, "embed_textures")
        box.separator()
        box.label(text="Preview Export")
        box.prop(settings, "preview_export_path")
        box.operator("astro_moba.export_preview_glb", icon="EXPORT")
        box.separator()
        box.label(text="General Export")
        box.prop(settings, "export_path")
        box.prop(settings, "export_mode")
        box.operator("astro_moba.export_glb", icon="EXPORT")

classes = (
    ASTRO_PT_tools_panel,
)
