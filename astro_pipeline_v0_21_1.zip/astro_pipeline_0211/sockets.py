import bpy
from .constants import SOCKETS
from .utils import get_armature, write_text_report
from mathutils import Vector

class ASTRO_OT_create_sockets(bpy.types.Operator):
    bl_idname = "astro_moba.create_sockets"
    bl_label = "Create Socket Bones"
    bl_description = "Create/recreate non-deforming attachment socket bones"

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        bpy.context.view_layer.objects.active = arm
        arm.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")

        created, skipped = [], []

        for socket_name, parent_name, offset in SOCKETS:
            parent = arm.data.edit_bones.get(parent_name)

            if not parent:
                skipped.append(f"{socket_name}: missing parent {parent_name}")
                continue

            existing = arm.data.edit_bones.get(socket_name)
            if existing:
                arm.data.edit_bones.remove(existing)

            socket_bone = arm.data.edit_bones.new(socket_name)
            base = parent.tail.copy()
            socket_bone.head = base + offset
            socket_bone.tail = socket_bone.head + Vector((0.00, 0.00, 0.12))
            socket_bone.parent = parent
            socket_bone.use_connect = False
            socket_bone.use_deform = False
            created.append(f"{socket_name} -> parent {parent_name}")

        bpy.ops.object.mode_set(mode="OBJECT")

        lines = ["========== SOCKET CREATION REPORT ==========", "", f"Armature: {arm.name}", "", "Created/Recreated:"]
        lines += [f"OK - {x}" for x in created] if created else ["None"]
        lines += ["", "Skipped:"]
        lines += [f"SKIPPED - {x}" for x in skipped] if skipped else ["None"]
        lines += ["", "========== END REPORT =========="]

        write_text_report("ASTRO_SOCKET_CREATION_REPORT", lines)
        self.report({"INFO"}, "Socket creation finished")
        return {"FINISHED"}

class ASTRO_OT_socket_report(bpy.types.Operator):
    bl_idname = "astro_moba.socket_report"
    bl_label = "Print Socket Report"
    bl_description = "Write socket bone information to a text report"

    def execute(self, context):
        arm = get_armature()
        lines = ["========== SOCKET CHECK REPORT =========="]

        if not arm:
            lines.append("ERROR: Could not find armature.")
        else:
            lines += [f"Found armature: {arm.name}", "", "Bones containing 'Socket':"]
            found = False
            for bone in arm.data.bones:
                if "Socket" in bone.name:
                    found = True
                    parent = bone.parent.name if bone.parent else "None"
                    lines.append(f" - {bone.name} | parent: {parent} | deform: {bone.use_deform}")
            if not found:
                lines.append("No socket bones found.")

        lines.append("========== END REPORT ==========")
        write_text_report("ASTRO_SOCKET_CHECK_REPORT", lines)
        self.report({"INFO"}, "Socket report created")
        return {"FINISHED"}

class ASTRO_OT_center_weapon_socket(bpy.types.Operator):
    bl_idname = "astro_moba.center_weapon_socket"
    bl_label = "Recenter Weapon Socket"
    bl_description = "Move WeaponSocket to RPalm tail with a default visible size"

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        bpy.context.view_layer.objects.active = arm
        arm.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")

        parent = arm.data.edit_bones.get("RPalm")
        socket = arm.data.edit_bones.get("WeaponSocket")
        if not parent or not socket:
            bpy.ops.object.mode_set(mode="OBJECT")
            self.report({"ERROR"}, "Need RPalm and WeaponSocket")
            return {"CANCELLED"}

        socket.parent = parent
        socket.use_connect = False
        socket.use_deform = False
        socket.head = parent.tail + Vector((0.00, -0.08, 0.00))
        socket.tail = socket.head + Vector((0.00, 0.00, 0.12))

        bpy.ops.object.mode_set(mode="OBJECT")
        self.report({"INFO"}, "WeaponSocket recentered")
        return {"FINISHED"}

class ASTRO_OT_center_belt_sockets(bpy.types.Operator):
    bl_idname = "astro_moba.center_belt_sockets"
    bl_label = "Recenter Belt Sockets"
    bl_description = "Move belt sockets to default pelvis offsets"

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        bpy.context.view_layer.objects.active = arm
        arm.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")

        parent = arm.data.edit_bones.get("Pelvis")
        if not parent:
            bpy.ops.object.mode_set(mode="OBJECT")
            self.report({"ERROR"}, "Missing Pelvis")
            return {"CANCELLED"}

        positions = {
            "BeltSocket_L": Vector((-0.18, 0.00, -0.10)),
            "BeltSocket_R": Vector((0.18, 0.00, -0.10)),
        }

        for socket_name, offset in positions.items():
            socket = arm.data.edit_bones.get(socket_name)
            if not socket:
                continue
            socket.parent = parent
            socket.use_connect = False
            socket.use_deform = False
            socket.head = parent.tail + offset
            socket.tail = socket.head + Vector((0.00, 0.00, 0.12))

        bpy.ops.object.mode_set(mode="OBJECT")
        self.report({"INFO"}, "Belt sockets recentered")
        return {"FINISHED"}

classes = (
    ASTRO_OT_create_sockets,
    ASTRO_OT_socket_report,
    ASTRO_OT_center_weapon_socket,
    ASTRO_OT_center_belt_sockets,
)
