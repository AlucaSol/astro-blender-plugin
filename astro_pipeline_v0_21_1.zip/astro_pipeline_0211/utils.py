import bpy
from .constants import ARMATURE_NAME

def get_armature():
    arm = bpy.data.objects.get(ARMATURE_NAME)
    if arm and arm.type == "ARMATURE":
        return arm

    active = bpy.context.object
    if active and active.type == "ARMATURE":
        return active

    for obj in bpy.data.objects:
        if obj.type == "ARMATURE":
            return obj

    return None

def write_text_report(name, lines):
    if name in bpy.data.texts:
        text = bpy.data.texts[name]
        text.clear()
    else:
        text = bpy.data.texts.new(name)

    text.write("\n".join(lines))

    for area in bpy.context.screen.areas:
        if area.type == "TEXT_EDITOR":
            area.spaces.active.text = text
            break

def is_descendant_of(obj, parent_obj):
    parent = obj.parent
    while parent:
        if parent == parent_obj:
            return True
        parent = parent.parent
    return False

def safe_object_mode():
    try:
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
