import bpy
from .poses import get_saved_pose_items
from .locomotion import refresh_locomotion_preview

class ASTRO_Settings(bpy.types.PropertyGroup):
    base_pose_enum: bpy.props.EnumProperty(
        name="Base Pose",
        description="Saved pose used as the upper-body/base pose",
        items=get_saved_pose_items,
        update=refresh_locomotion_preview,
    )

    movement_type: bpy.props.EnumProperty(
        name="Movement Type",
        default="RUN",
        description="Type of locomotion to generate",
        items=[
            ("WALK", "Walk", "Generate a slower walk cycle"),
            ("RUN", "Run", "Generate a standard run cycle"),
            ("SPRINT", "Sprint", "Generate a faster, more aggressive sprint cycle"),
        ],
        update=refresh_locomotion_preview,
    )

    stride_length: bpy.props.FloatProperty(
        name="Stride Length",
        default=28.0,
        min=5.0,
        max=60.0,
        description="How far the legs swing",
        update=refresh_locomotion_preview,
    )

    vertical_bob: bpy.props.FloatProperty(
        name="Vertical Bob",
        default=8.0,
        min=0.0,
        max=30.0,
        description="How much the body bobs during locomotion",
        update=refresh_locomotion_preview,
    )

    bob_axis: bpy.props.EnumProperty(
        name="Bob Axis",
        default="Z",
        description="Which pelvis location axis is used for visible body bob",
        items=[
            ("X", "X", "Apply bob on local X location"),
            ("Y", "Y", "Apply bob on local Y location"),
            ("Z", "Z", "Apply bob on local Z location"),
        ],
        update=refresh_locomotion_preview,
    )

    torso_twist: bpy.props.FloatProperty(
        name="Torso Twist",
        default=4.0,
        min=0.0,
        max=20.0,
        description="How much the pelvis/spine twists",
        update=refresh_locomotion_preview,
    )

    forward_lean: bpy.props.FloatProperty(
        name="Forward Lean",
        default=8.0,
        min=0.0,
        max=25.0,
        description="Forward lean of the torso",
        update=refresh_locomotion_preview,
    )

    speed_scale: bpy.props.FloatProperty(
        name="Speed Scale",
        default=1.0,
        min=0.5,
        max=2.0,
        description="Reserved for future export/game timing; current generator uses fixed frames",
    )

    live_preview: bpy.props.BoolProperty(
        name="Live Preview",
        default=False,
        description="Automatically regenerate the selected locomotion action when sliders change",
    )

    bake_action_name: bpy.props.StringProperty(
        name="Action Name",
        default="Run_RifleReady",
        description="Name of the Blender Action that will be baked/exported",
    )

    bake_target_armature: bpy.props.StringProperty(
        name="Target Armature",
        default="Armature_Preview",
        description="Armature object to receive baked animation. Use Armature_Preview for converted preview exports.",
    )

    export_path: bpy.props.StringProperty(
        name="Export GLB Path",
        default="//astro_moba_character.glb",
        subtype="FILE_PATH",
        description="Output filepath for GLB export. // means relative to the current .blend file",
    )

    export_mode: bpy.props.EnumProperty(
        name="Export Mode",
        default="VISIBLE",
        description="Which objects to include in the GLB export",
        items=[
            ("RELATED", "Related Meshes", "Export armature plus meshes using or parented to the armature"),
            ("VISIBLE", "All Visible Meshes", "Export armature plus all visible mesh objects in the scene"),
        ],
    )

    embed_textures: bpy.props.BoolProperty(
        name="Embed Textures",
        default=True,
        description="Pack textures into the GLB file where possible",
    )

    preview_export_path: bpy.props.StringProperty(
        name="Preview GLB Path",
        default="//astro_preview_character.glb",
        subtype="FILE_PATH",
        description="Output filepath for exporting only the Astro_Preview collection",
    )

    manual_mapping_target: bpy.props.StringProperty(
        name="Manual Target Bone",
        default="BackpackSocket",
        description="Bone/socket name used by Apply Manual Mapping",
    )

classes = (
    ASTRO_Settings,
)
