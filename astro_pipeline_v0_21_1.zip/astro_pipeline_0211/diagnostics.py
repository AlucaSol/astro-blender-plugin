import bpy
from .utils import get_armature, write_text_report, is_descendant_of

class ASTRO_OT_analyze_character(bpy.types.Operator):
    bl_idname = "astro_moba.analyze_character"
    bl_label = "Analyze Character"
    bl_description = "Create a detailed diagnostic report of scene objects, hierarchy, meshes, materials, textures, modifiers, and actions"

    def execute(self, context):
        arm = get_armature()
        lines = []
        lines.append("========== ASTRO MOBA CHARACTER DIAGNOSTIC ==========")
        lines.append("")
        lines.append(f"Blender version: {bpy.app.version_string}")
        lines.append(f"Scene: {bpy.context.scene.name}")
        lines.append("")

        if not arm:
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_CHARACTER_DIAGNOSTIC", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        lines.append("ARMATURE")
        lines.append(f"Name: {arm.name}")
        lines.append(f"Type: {arm.type}")
        lines.append(f"Location: {tuple(round(v, 5) for v in arm.location)}")
        lines.append(f"Rotation mode: {arm.rotation_mode}")
        lines.append(f"Scale: {tuple(round(v, 5) for v in arm.scale)}")
        lines.append(f"Visible: {arm.visible_get()}")
        lines.append(f"Hide viewport: {arm.hide_viewport}")
        lines.append(f"Hide render: {arm.hide_render}")
        lines.append(f"Bone count: {len(arm.data.bones)}")
        lines.append("")

        lines.append("MESH DIAGNOSTICS")
        mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH"]
        if not mesh_objects:
            lines.append("No mesh objects found.")

        for obj in mesh_objects:
            mesh = obj.data
            parent_name = obj.parent.name if obj.parent else "None"
            descendant = is_descendant_of(obj, arm)
            lines.append(f"- Mesh object: {obj.name}")
            lines.append(f"    Mesh data name: {mesh.name}")
            lines.append(f"    Parent: {parent_name}")
            lines.append(f"    Descendant of armature: {descendant}")
            lines.append(f"    Visible: {obj.visible_get()}")
            lines.append(f"    Hide viewport: {obj.hide_viewport}")
            lines.append(f"    Hide render: {obj.hide_render}")
            lines.append(f"    Location: {tuple(round(v, 5) for v in obj.location)}")
            lines.append(f"    Scale: {tuple(round(v, 5) for v in obj.scale)}")
            lines.append(f"    Dimensions: {tuple(round(v, 5) for v in obj.dimensions)}")
            lines.append(f"    Vertices: {len(mesh.vertices)}")
            lines.append(f"    Polygons: {len(mesh.polygons)}")
            lines.append(f"    Materials: {len(obj.material_slots)}")
            lines.append(f"    Vertex groups: {len(obj.vertex_groups)}")

            armature_mods = []
            for mod in obj.modifiers:
                if mod.type == "ARMATURE":
                    target = mod.object.name if mod.object else "None"
                    armature_mods.append(target)
                lines.append(f"    Modifier: {mod.name} | type: {mod.type}")

            if armature_mods:
                lines.append(f"    Armature modifier targets: {', '.join(armature_mods)}")
            else:
                lines.append("    Armature modifier targets: none")
            lines.append("")

        lines.append("MATERIAL AND TEXTURE DIAGNOSTICS")
        if not bpy.data.materials:
            lines.append("No materials found.")
        for mat in bpy.data.materials:
            lines.append(f"- Material: {mat.name}")
            lines.append(f"    Use nodes: {mat.use_nodes}")
            if mat.use_nodes and mat.node_tree:
                for node in mat.node_tree.nodes:
                    lines.append(f"    Node: {node.name} | type: {node.type}")
                    if node.type == "TEX_IMAGE":
                        image = node.image
                        if image:
                            image_path = bpy.path.abspath(image.filepath) if image.filepath else "No filepath / packed or generated"
                            packed = bool(image.packed_file)
                            lines.append(f"        Image: {image.name}")
                            lines.append(f"        Path: {image_path}")
                            lines.append(f"        Packed in .blend: {packed}")
                            lines.append(f"        Size: {image.size[0]} x {image.size[1]}")
                        else:
                            lines.append("        Image: None")
        lines.append("")

        lines.append("ACTIONS")
        if not bpy.data.actions:
            lines.append("No actions found.")
        for action in bpy.data.actions:
            fcurve_count = len(action.fcurves) if hasattr(action, "fcurves") else "Unavailable"
            frame_range = tuple(round(v, 3) for v in action.frame_range) if hasattr(action, "frame_range") else "Unavailable"
            lines.append(f"- {action.name} | fcurves: {fcurve_count} | frame range: {frame_range}")
        lines.append("")

        lines.append("EXPORT / CONVERSION CANDIDATE SUMMARY")
        visible_meshes = [obj.name for obj in mesh_objects if obj.visible_get() and not obj.hide_render]
        descendants_meshes = [obj.name for obj in mesh_objects if is_descendant_of(obj, arm)]
        armature_modifier_meshes = []
        rigid_descendant_meshes = []
        for obj in mesh_objects:
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)
            if has_arm_mod:
                armature_modifier_meshes.append(obj.name)
            elif is_descendant_of(obj, arm):
                rigid_descendant_meshes.append(obj.name)

        lines.append(f"Visible renderable meshes: {len(visible_meshes)}")
        for name in visible_meshes:
            lines.append(f"  - {name}")

        lines.append(f"Meshes descended from armature: {len(descendants_meshes)}")
        for name in descendants_meshes:
            lines.append(f"  - {name}")

        lines.append(f"Skinned meshes with armature modifier: {len(armature_modifier_meshes)}")
        for name in armature_modifier_meshes:
            lines.append(f"  - {name}")

        lines.append(f"Rigid child/accessory meshes: {len(rigid_descendant_meshes)}")
        for name in rigid_descendant_meshes:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append("========== END DIAGNOSTIC ==========")

        write_text_report("ASTRO_CHARACTER_DIAGNOSTIC", lines)
        self.report({"INFO"}, "Character diagnostic report created")
        return {"FINISHED"}


class ASTRO_OT_classify_asset(bpy.types.Operator):
    bl_idname = "astro_moba.classify_asset"
    bl_label = "Classify Asset"
    bl_description = "Classify the current character asset and recommend the correct Astro Pipeline conversion path"

    def execute(self, context):
        arm = get_armature()
        lines = ["========== ASTRO MOBA ASSET CLASSIFIER ==========", ""]

        if not arm or arm.type != "ARMATURE":
            lines.append("Asset Type: Unknown / No Armature")
            lines.append("Confidence: Low")
            lines.append("")
            lines.append("Reason:")
            lines.append("  No usable armature was found in the scene.")
            lines.append("")
            lines.append("Recommended Conversion:")
            lines.append("  Static Mesh or Manual Rigging Required")
            lines.append("")
            lines.append("========== END ASSET CLASSIFIER ==========")
            write_text_report("ASTRO_ASSET_CLASSIFIER", lines)
            self.report({"WARNING"}, "No armature found")
            return {"FINISHED"}

        mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH" and is_descendant_of(obj, arm)]

        skinned = []
        rigid = []
        equipment = []
        helper_or_junk = []

        equipment_keywords = ["rifle", "gun", "weapon", "sword", "pistol", "shield", "staff", "bow", "axe"]
        helper_keywords = ["plane", "helper", "marker", "locator", "collider", "collision"]

        for obj in mesh_objects:
            name_lower = obj.name.lower()
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)

            if any(keyword in name_lower for keyword in helper_keywords):
                helper_or_junk.append(obj)
            elif any(keyword in name_lower for keyword in equipment_keywords):
                equipment.append(obj)
            elif has_arm_mod:
                skinned.append(obj)
            else:
                rigid.append(obj)

        socket_bones = [bone.name for bone in arm.data.bones if "Socket" in bone.name]

        broken_images = []
        loaded_images = []
        for image in bpy.data.images:
            if image.name in {"Render Result", "Viewer Node"}:
                continue
            if image.size[0] == 0 or image.size[1] == 0:
                broken_images.append(image)
            else:
                loaded_images.append(image)

        armature_scale = tuple(round(v, 5) for v in arm.scale)
        non_unit_armature = armature_scale != (1.0, 1.0, 1.0)

        # Classification rules
        if skinned and (rigid or equipment):
            asset_type = "Hybrid Character"
            recommended = "Hybrid Unity Character Pipeline"
            confidence = 95
        elif skinned and not rigid and not equipment:
            asset_type = "Fully Skinned Character"
            recommended = "Skinned Character Pipeline"
            confidence = 90
        elif not skinned and rigid:
            asset_type = "Rigid / Modular Character"
            recommended = "Rigid Character Pipeline"
            confidence = 75
        else:
            asset_type = "Unknown Character Asset"
            recommended = "Manual Inspection Required"
            confidence = 40

        warnings = []
        if non_unit_armature:
            warnings.append(f"Armature scale is {armature_scale}; expected (1, 1, 1).")
            confidence -= 10
        if broken_images:
            warnings.append(f"{len(broken_images)} broken texture/image references detected.")
            confidence -= 8
        if helper_or_junk:
            warnings.append(f"{len(helper_or_junk)} possible helper/junk meshes detected.")
            confidence -= 3
        if not socket_bones:
            warnings.append("No socket bones detected.")
            confidence -= 5
        if not bpy.data.actions:
            warnings.append("No animation actions currently stored.")
            confidence -= 3

        if confidence < 0:
            confidence = 0

        lines.append(f"Asset Name: {arm.name}")
        lines.append(f"Asset Type: {asset_type}")
        lines.append(f"Confidence: {confidence}%")
        lines.append("")
        lines.append("Summary:")
        lines.append(f"  Armature: {arm.name}")
        lines.append(f"  Armature scale: {armature_scale}")
        lines.append(f"  Total meshes under armature: {len(mesh_objects)}")
        lines.append(f"  Skinned meshes: {len(skinned)}")
        lines.append(f"  Rigid/accessory meshes: {len(rigid)}")
        lines.append(f"  Equipment meshes: {len(equipment)}")
        lines.append(f"  Possible helper/junk meshes: {len(helper_or_junk)}")
        lines.append(f"  Socket bones: {len(socket_bones)}")
        lines.append(f"  Loaded images: {len(loaded_images)}")
        lines.append(f"  Broken images: {len(broken_images)}")
        lines.append(f"  Actions: {len(bpy.data.actions)}")
        lines.append("")
        lines.append("Skinned Meshes:")
        if skinned:
            for obj in skinned:
                lines.append(f"  - {obj.name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Rigid / Accessory Meshes:")
        if rigid:
            for obj in rigid:
                lines.append(f"  - {obj.name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Equipment Meshes:")
        if equipment:
            for obj in equipment:
                lines.append(f"  - {obj.name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Possible Helper / Junk Meshes:")
        if helper_or_junk:
            for obj in helper_or_junk:
                lines.append(f"  - {obj.name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Socket Bones:")
        if socket_bones:
            for name in socket_bones:
                lines.append(f"  - {name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Warnings:")
        if warnings:
            for warning in warnings:
                lines.append(f"  - {warning}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Recommended Conversion:")
        lines.append(f"  {recommended}")

        lines.append("")
        lines.append("Recommended Next Steps:")
        if asset_type == "Hybrid Character":
            lines.append("  1. Run Bind Pose Inspector.")
            lines.append("  2. Preserve skinned mesh bind pose.")
            lines.append("  3. Convert rigid accessories separately.")
            lines.append("  4. Repair texture references.")
            lines.append("  5. Generate/verify Actions.")
            lines.append("  6. Export test GLB.")
        elif asset_type == "Fully Skinned Character":
            lines.append("  1. Validate rig.")
            lines.append("  2. Create sockets if missing.")
            lines.append("  3. Generate animations.")
            lines.append("  4. Export GLB.")
        elif asset_type == "Rigid / Modular Character":
            lines.append("  1. Identify intended moving parts.")
            lines.append("  2. Add or assign attachment bones.")
            lines.append("  3. Parent rigid pieces to sockets/bones.")
            lines.append("  4. Export GLB.")
        else:
            lines.append("  1. Run Analyze Character.")
            lines.append("  2. Inspect manually before conversion.")

        lines.append("")
        lines.append("========== END ASSET CLASSIFIER ==========")

        write_text_report("ASTRO_ASSET_CLASSIFIER", lines)
        self.report({"INFO"}, f"Asset classified: {asset_type}")
        return {"FINISHED"}



class ASTRO_OT_validate_preview_scene(bpy.types.Operator):
    bl_idname = "astro_moba.validate_preview_scene"
    bl_label = "Validate Preview Scene"
    bl_description = "Validate the Astro_Preview collection before export/import testing"

    preview_collection_name: bpy.props.StringProperty(
        name="Preview Collection",
        default="Astro_Preview",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        collection = bpy.data.collections.get(self.preview_collection_name)
        lines = ["========== ASTRO MOBA PREVIEW VALIDATION ==========", ""]

        if not collection:
            lines.append(f"ERROR: Preview collection not found: {self.preview_collection_name}")
            lines.append("Run 2. Convert → Preview Conversion first.")
            write_text_report("ASTRO_PREVIEW_VALIDATION", lines)
            self.report({"ERROR"}, "Preview collection not found")
            return {"CANCELLED"}

        objects = list(collection.objects)
        armatures = [obj for obj in objects if obj.type == "ARMATURE"]
        meshes = [obj for obj in objects if obj.type == "MESH"]

        if armatures:
            arm = armatures[0]
        else:
            arm = None

        skinned = []
        rigid = []
        bone_parented = []
        non_bone_parented_rigid = []
        suspicious = []
        missing_textures = []
        loaded_textures = []

        if arm:
            for obj in meshes:
                arm_mods = [mod for mod in obj.modifiers if mod.type == "ARMATURE"]
                targets_preview_arm = [mod for mod in arm_mods if mod.object == arm]

                if targets_preview_arm:
                    skinned.append(obj)
                else:
                    rigid.append(obj)

                if obj.parent == arm and obj.parent_type == "BONE":
                    bone_parented.append(obj)
                elif not targets_preview_arm:
                    non_bone_parented_rigid.append(obj)

        for image in bpy.data.images:
            if image.name in {"Render Result", "Viewer Node"}:
                continue
            if image.size[0] == 0 or image.size[1] == 0:
                missing_textures.append(image)
            else:
                loaded_textures.append(image)

        if len(armatures) != 1:
            suspicious.append(f"Expected exactly 1 preview armature, found {len(armatures)}.")

        if not meshes:
            suspicious.append("No mesh objects found in preview collection.")

        if arm:
            if tuple(round(v, 5) for v in arm.scale) != (0.01, 0.01, 0.01):
                suspicious.append(f"Preview armature scale is {tuple(round(v, 5) for v in arm.scale)}. This may be okay, but differs from current legacy-preserve strategy.")

        if not skinned:
            suspicious.append("No skinned meshes found.")

        if non_bone_parented_rigid:
            suspicious.append(f"{len(non_bone_parented_rigid)} rigid meshes are not bone-parented and may need manual review.")

        if not bpy.data.actions:
            suspicious.append("No animation Actions found. Generate animation before final game export.")

        score = 100
        if len(armatures) != 1:
            score -= 25
        if not meshes:
            score -= 25
        if not skinned:
            score -= 20
        if non_bone_parented_rigid:
            score -= min(20, len(non_bone_parented_rigid) * 5)
        if missing_textures:
            score -= min(15, len(missing_textures) * 5)
        if not bpy.data.actions:
            score -= 5

        if score < 0:
            score = 0

        lines.append(f"Preview collection: {collection.name}")
        lines.append(f"Validation score: {score}/100")
        lines.append("")
        lines.append("Object counts:")
        lines.append(f"  Armatures: {len(armatures)}")
        lines.append(f"  Meshes: {len(meshes)}")
        lines.append(f"  Skinned meshes: {len(skinned)}")
        lines.append(f"  Rigid/accessory meshes: {len(rigid)}")
        lines.append(f"  Bone-parented rigid meshes: {len(bone_parented)}")
        lines.append(f"  Non-bone-parented rigid/manual meshes: {len(non_bone_parented_rigid)}")
        lines.append(f"  Actions in .blend: {len(bpy.data.actions)}")
        lines.append(f"  Loaded textures/images: {len(loaded_textures)}")
        lines.append(f"  Broken texture/image refs: {len(missing_textures)}")
        lines.append("")

        lines.append("Armatures:")
        if armatures:
            for obj in armatures:
                lines.append(f"  - {obj.name} | scale: {tuple(round(v, 5) for v in obj.scale)} | bones: {len(obj.data.bones)}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Skinned Meshes:")
        if skinned:
            for obj in skinned:
                arm_mods = [
                    mod.object.name if mod.object else "None"
                    for mod in obj.modifiers
                    if mod.type == "ARMATURE"
                ]
                lines.append(f"  - {obj.name} | parent: {obj.parent.name if obj.parent else 'None'} | armature mods: {', '.join(arm_mods)}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Bone-parented Rigid Meshes:")
        if bone_parented:
            for obj in bone_parented:
                lines.append(f"  - {obj.name} | bone: {obj.parent_bone} | scale: {tuple(round(v, 5) for v in obj.scale)}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Manual / Non-bone-parented Rigid Meshes:")
        if non_bone_parented_rigid:
            for obj in non_bone_parented_rigid:
                lines.append(f"  - {obj.name} | parent: {obj.parent.name if obj.parent else 'None'} | parent_type: {obj.parent_type}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Broken Texture/Image References:")
        if missing_textures:
            for image in missing_textures:
                path = bpy.path.abspath(image.filepath) if image.filepath else "No filepath"
                lines.append(f"  - {image.name} | path: {path}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Validation Warnings:")
        if suspicious:
            for item in suspicious:
                lines.append(f"  - {item}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Recommended Next Step:")
        if score >= 80:
            lines.append("  Preview is suitable for GLB export/import testing.")
        elif score >= 60:
            lines.append("  Preview is usable for testing, but manual review items remain.")
        else:
            lines.append("  Fix preview issues before export/import testing.")
        lines.append("")
        lines.append("========== END PREVIEW VALIDATION ==========")

        write_text_report("ASTRO_PREVIEW_VALIDATION", lines)
        self.report({"INFO"}, f"Preview validation score: {score}/100")
        return {"FINISHED"}


classes = (
    ASTRO_OT_analyze_character,
    ASTRO_OT_classify_asset,
    ASTRO_OT_validate_preview_scene,
)
