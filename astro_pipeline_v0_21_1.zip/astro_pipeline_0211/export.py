import bpy
from .utils import get_armature, write_text_report, safe_object_mode, is_descendant_of

class ASTRO_OT_export_glb(bpy.types.Operator):
    bl_idname = "astro_moba.export_glb"
    bl_label = "Export GLB"
    bl_description = "Export the character, armature, visible meshes, textures, sockets, and generated actions as a GLB for Godot"

    def execute(self, context):
        settings = context.scene.astro_moba_settings
        arm = get_armature()

        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        filepath = bpy.path.abspath(settings.export_path)
        safe_object_mode()
        bpy.ops.object.select_all(action="DESELECT")

        selected = []
        arm.select_set(True)
        selected.append(arm.name)

        for obj in bpy.data.objects:
            if obj.type != "MESH":
                continue

            should_export = False
            if settings.export_mode == "VISIBLE":
                should_export = obj.visible_get() and not obj.hide_render
            else:
                should_export = is_descendant_of(obj, arm) or any(
                    mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers
                )

            if should_export:
                obj.select_set(True)
                selected.append(obj.name)

        bpy.context.view_layer.objects.active = arm

        export_kwargs = {
            "filepath": filepath,
            "export_format": "GLB",
            "use_selection": True,
            "export_animations": True,
            "export_nla_strips": False,
            "export_all_influences": True,
            "export_skins": True,
            "export_yup": True,
        }

        if settings.embed_textures:
            export_kwargs["export_image_format"] = "AUTO"
        else:
            export_kwargs["export_image_format"] = "NONE"

        try:
            bpy.ops.export_scene.gltf(**export_kwargs)
        except TypeError:
            export_kwargs.pop("export_image_format", None)
            try:
                bpy.ops.export_scene.gltf(**export_kwargs)
            except Exception as e:
                self.report({"ERROR"}, f"GLB export failed: {e}")
                return {"CANCELLED"}
        except Exception as e:
            self.report({"ERROR"}, f"GLB export failed: {e}")
            return {"CANCELLED"}

        lines = [
            "========== ASTRO MOBA GLB EXPORT REPORT ==========",
            "",
            f"Exported to: {filepath}",
            f"Export mode: {settings.export_mode}",
            f"Embed textures requested: {settings.embed_textures}",
            "",
            "Selected objects:",
        ]
        lines += [f" - {name}" for name in selected]
        lines += ["", "Actions in file:"]
        lines += [f" - {action.name}" for action in bpy.data.actions] if bpy.data.actions else ["No actions found."]
        lines += ["", "========== END REPORT =========="]
        write_text_report("ASTRO_GLB_EXPORT_REPORT", lines)

        self.report({"INFO"}, f"Exported GLB: {filepath}")
        return {"FINISHED"}


class ASTRO_OT_export_preview_glb(bpy.types.Operator):
    bl_idname = "astro_moba.export_preview_glb"
    bl_label = "Export Preview GLB"
    bl_description = "Export only the Astro_Preview collection as a GLB for Blender/Godot validation"

    preview_collection_name: bpy.props.StringProperty(
        name="Preview Collection",
        default="Astro_Preview",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        settings = context.scene.astro_moba_settings
        collection = bpy.data.collections.get(self.preview_collection_name)

        lines = ["========== ASTRO MOBA PREVIEW GLB EXPORT ==========", ""]

        if not collection:
            lines.append(f"ERROR: Preview collection not found: {self.preview_collection_name}")
            lines.append("Run 2. Convert → Preview Conversion first.")
            write_text_report("ASTRO_PREVIEW_GLB_EXPORT_REPORT", lines)
            self.report({"ERROR"}, "Preview collection not found")
            return {"CANCELLED"}

        filepath = bpy.path.abspath(settings.preview_export_path)
        safe_object_mode()
        bpy.ops.object.select_all(action="DESELECT")

        selected = []
        armatures = []
        meshes = []

        # Select all objects directly in the preview collection.
        for obj in collection.objects:
            if obj.type in {"ARMATURE", "MESH"}:
                obj.select_set(True)
                selected.append(obj.name)
                if obj.type == "ARMATURE":
                    armatures.append(obj)
                elif obj.type == "MESH":
                    meshes.append(obj)

        if not selected:
            lines.append(f"ERROR: No exportable objects found in {collection.name}.")
            write_text_report("ASTRO_PREVIEW_GLB_EXPORT_REPORT", lines)
            self.report({"ERROR"}, "No exportable preview objects")
            return {"CANCELLED"}

        if armatures:
            bpy.context.view_layer.objects.active = armatures[0]
        else:
            bpy.context.view_layer.objects.active = bpy.data.objects.get(selected[0])

        export_kwargs = {
            "filepath": filepath,
            "export_format": "GLB",
            "use_selection": True,
            "export_animations": True,
            "export_nla_strips": False,
            "export_all_influences": True,
            "export_skins": True,
            "export_yup": True,
        }

        if settings.embed_textures:
            export_kwargs["export_image_format"] = "AUTO"
        else:
            export_kwargs["export_image_format"] = "NONE"

        try:
            bpy.ops.export_scene.gltf(**export_kwargs)
        except TypeError:
            export_kwargs.pop("export_image_format", None)
            try:
                bpy.ops.export_scene.gltf(**export_kwargs)
            except Exception as e:
                lines.append(f"ERROR: GLB export failed: {e}")
                write_text_report("ASTRO_PREVIEW_GLB_EXPORT_REPORT", lines)
                self.report({"ERROR"}, f"Preview GLB export failed: {e}")
                return {"CANCELLED"}
        except Exception as e:
            lines.append(f"ERROR: GLB export failed: {e}")
            write_text_report("ASTRO_PREVIEW_GLB_EXPORT_REPORT", lines)
            self.report({"ERROR"}, f"Preview GLB export failed: {e}")
            return {"CANCELLED"}

        lines.append(f"Exported to: {filepath}")
        lines.append(f"Preview collection: {collection.name}")
        lines.append(f"Embed textures requested: {settings.embed_textures}")
        lines.append("")
        lines.append(f"Armatures exported: {len(armatures)}")
        for obj in armatures:
            lines.append(f"  - {obj.name} | scale: {tuple(round(v, 5) for v in obj.scale)}")
        lines.append("")
        lines.append(f"Meshes exported: {len(meshes)}")
        for obj in meshes:
            parent = obj.parent.name if obj.parent else "None"
            parent_bone = obj.parent_bone if obj.parent_type == "BONE" else ""
            arm_mods = [
                mod.object.name if mod.object else "None"
                for mod in obj.modifiers
                if mod.type == "ARMATURE"
            ]
            lines.append(f"  - {obj.name} | parent: {parent} {parent_bone} | armature mods: {', '.join(arm_mods) if arm_mods else 'none'}")
        lines.append("")
        lines.append("Actions in file:")
        if bpy.data.actions:
            for action in bpy.data.actions:
                lines.append(f"  - {action.name}")
        else:
            lines.append("  No actions found.")
        lines.append("")
        lines.append("Next validation step:")
        lines.append("  Import this GLB into a fresh Blender file or Godot test scene.")
        lines.append("  Confirm mesh positions, rotations, materials, armature, and animations.")
        lines.append("")
        lines.append("========== END PREVIEW GLB EXPORT ==========")

        write_text_report("ASTRO_PREVIEW_GLB_EXPORT_REPORT", lines)
        self.report({"INFO"}, f"Exported preview GLB: {filepath}")
        return {"FINISHED"}


classes = (
    ASTRO_OT_export_glb,
    ASTRO_OT_export_preview_glb,
)
