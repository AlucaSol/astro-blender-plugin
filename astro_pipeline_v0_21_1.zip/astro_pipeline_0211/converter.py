import bpy
from .utils import get_armature, write_text_report, is_descendant_of

class ASTRO_OT_conversion_readiness(bpy.types.Operator):
    bl_idname = "astro_moba.conversion_readiness"
    bl_label = "Conversion Readiness"
    bl_description = "Analyze whether this legacy character is ready for safe conversion"

    def execute(self, context):
        arm = get_armature()
        lines = ["========== ASTRO MOBA CONVERSION READINESS ==========", ""]

        if not arm:
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_CONVERSION_READINESS", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH"]
        descendant_meshes = [obj for obj in mesh_objects if is_descendant_of(obj, arm)]
        skinned_meshes = []
        rigid_meshes = []

        for obj in descendant_meshes:
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)
            if has_arm_mod:
                skinned_meshes.append(obj)
            else:
                rigid_meshes.append(obj)

        broken_images = []
        loaded_images = []

        for image in bpy.data.images:
            if image.name in {"Render Result", "Viewer Node"}:
                continue
            if image.size[0] == 0 or image.size[1] == 0:
                broken_images.append(image)
            else:
                loaded_images.append(image)

        score = 100
        warnings = []

        if tuple(round(v, 5) for v in arm.scale) != (1.0, 1.0, 1.0):
            score -= 20
            warnings.append(f"Armature scale is {tuple(round(v, 5) for v in arm.scale)}; expected (1, 1, 1).")

        if rigid_meshes:
            score -= 15
            warnings.append(f"{len(rigid_meshes)} rigid child/accessory meshes detected. These need safe conversion handling.")

        if broken_images:
            score -= 15
            warnings.append(f"{len(broken_images)} broken/missing image references detected.")

        if not bpy.data.actions:
            score -= 10
            warnings.append("No actions found. Generate animations before export.")

        if score < 0:
            score = 0

        lines.append(f"Armature: {arm.name}")
        lines.append(f"Compatibility score: {score}/100")
        lines.append("")
        lines.append(f"Descendant meshes: {len(descendant_meshes)}")
        lines.append(f"Skinned meshes: {len(skinned_meshes)}")
        for obj in skinned_meshes:
            lines.append(f"  - {obj.name}")
        lines.append("")
        lines.append(f"Rigid/accessory meshes: {len(rigid_meshes)}")
        for obj in rigid_meshes:
            lines.append(f"  - {obj.name}")
        lines.append("")
        lines.append(f"Loaded images: {len(loaded_images)}")
        for image in loaded_images:
            lines.append(f"  - {image.name} ({image.size[0]}x{image.size[1]})")
        lines.append("")
        lines.append(f"Broken images: {len(broken_images)}")
        for image in broken_images:
            lines.append(f"  - {image.name} | path: {bpy.path.abspath(image.filepath) if image.filepath else 'No path'}")
        lines.append("")
        lines.append("Warnings:")
        if warnings:
            for warning in warnings:
                lines.append(f"  - {warning}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Next safe conversion steps:")
        lines.append("  1. Work from a backup copy.")
        lines.append("  2. Remove known prefab junk/helper objects.")
        lines.append("  3. Handle rigid child meshes before applying armature scale.")
        lines.append("  4. Relink or replace broken textures.")
        lines.append("  5. Generate animations.")
        lines.append("  6. Export test GLB.")
        lines.append("")
        lines.append("========== END READINESS REPORT ==========")

        write_text_report("ASTRO_CONVERSION_READINESS", lines)
        self.report({"INFO"}, f"Conversion readiness score: {score}/100")
        return {"FINISHED"}


class ASTRO_OT_prepare_conversion(bpy.types.Operator):
    bl_idname = "astro_moba.prepare_conversion"
    bl_label = "Prepare Conversion"
    bl_description = "Duplicate the current legacy character into a safe Astro_Converted collection without modifying the original"

    converted_collection_name: bpy.props.StringProperty(
        name="Converted Collection",
        default="Astro_Converted",
    )

    ignore_names: bpy.props.StringProperty(
        name="Ignore Objects",
        default="Plane.013",
        description="Comma-separated object names to exclude from the converted duplicate",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        arm = get_armature()
        lines = ["========== ASTRO MOBA PREPARE CONVERSION ==========", ""]

        if not arm:
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_PREPARE_CONVERSION_REPORT", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        ignore_set = {name.strip() for name in self.ignore_names.split(",") if name.strip()}

        source_meshes = []
        ignored = []

        for obj in bpy.data.objects:
            if obj.type != "MESH":
                continue

            if not is_descendant_of(obj, arm):
                continue

            if obj.name in ignore_set:
                ignored.append(obj.name)
                continue

            source_meshes.append(obj)

        # Remove prior converted collection if it exists, but only remove duplicated objects inside it.
        existing_collection = bpy.data.collections.get(self.converted_collection_name)
        if existing_collection:
            for obj in list(existing_collection.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(existing_collection)

        converted_collection = bpy.data.collections.new(self.converted_collection_name)
        bpy.context.scene.collection.children.link(converted_collection)

        # Duplicate armature object and armature data so the source remains untouched.
        arm_copy = arm.copy()
        arm_copy.data = arm.data.copy()
        arm_copy.name = arm.name + "_Astro"
        arm_copy.data.name = arm.data.name + "_Astro"
        converted_collection.objects.link(arm_copy)

        copied = []
        mesh_map = {}

        for obj in source_meshes:
            obj_copy = obj.copy()
            obj_copy.data = obj.data.copy()
            obj_copy.animation_data_clear()
            obj_copy.name = obj.name + "_Astro"
            obj_copy.data.name = obj.data.name + "_Astro"
            converted_collection.objects.link(obj_copy)
            mesh_map[obj.name] = obj_copy
            copied.append(obj.name)

        # Rebuild parenting relationships inside the duplicate set.
        for obj in source_meshes:
            obj_copy = mesh_map[obj.name]

            if obj.parent == arm:
                obj_copy.parent = arm_copy
                obj_copy.matrix_parent_inverse = obj.matrix_parent_inverse.copy()
            elif obj.parent and obj.parent.name in mesh_map:
                obj_copy.parent = mesh_map[obj.parent.name]
                obj_copy.matrix_parent_inverse = obj.matrix_parent_inverse.copy()
            else:
                obj_copy.parent = arm_copy if is_descendant_of(obj, arm) else None

            # Retarget armature modifiers to the duplicated armature.
            for mod in obj_copy.modifiers:
                if mod.type == "ARMATURE" and mod.object == arm:
                    mod.object = arm_copy

        # Put the duplicates into the converted collection only.
        for obj in [arm_copy] + list(mesh_map.values()):
            for collection in list(obj.users_collection):
                if collection != converted_collection:
                    collection.objects.unlink(obj)

        # Diagnostics on duplicate
        rigid_duplicates = []
        skinned_duplicates = []

        for obj in mesh_map.values():
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm_copy for mod in obj.modifiers)
            if has_arm_mod:
                skinned_duplicates.append(obj.name)
            else:
                rigid_duplicates.append(obj.name)

        lines.append(f"Source armature: {arm.name}")
        lines.append(f"Created converted collection: {converted_collection.name}")
        lines.append(f"Created duplicate armature: {arm_copy.name}")
        lines.append("")
        lines.append("Ignored source objects:")
        if ignored:
            for name in ignored:
                lines.append(f"  - {name}")
        else:
            lines.append("  None")
        lines.append("")
        lines.append(f"Copied meshes: {len(copied)}")
        for name in copied:
            lines.append(f"  - {name} -> {mesh_map[name].name}")

        lines.append("")
        lines.append(f"Skinned duplicate meshes: {len(skinned_duplicates)}")
        for name in skinned_duplicates:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append(f"Rigid/accessory duplicate meshes: {len(rigid_duplicates)}")
        for name in rigid_duplicates:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append("Scale status:")
        lines.append(f"  Source armature scale: {tuple(round(v, 5) for v in arm.scale)}")
        lines.append(f"  Duplicate armature scale: {tuple(round(v, 5) for v in arm_copy.scale)}")
        lines.append("")
        lines.append("Important:")
        lines.append("  The original character was not modified.")
        lines.append("  This step only creates a safe duplicate collection.")
        lines.append("  Actual scale/hierarchy conversion will be added in the next build.")
        lines.append("")
        lines.append("========== END PREPARE CONVERSION ==========")

        write_text_report("ASTRO_PREPARE_CONVERSION_REPORT", lines)
        self.report({"INFO"}, f"Prepared duplicate collection: {converted_collection.name}")
        return {"FINISHED"}



class ASTRO_OT_convert_duplicate_scale(bpy.types.Operator):
    bl_idname = "astro_moba.convert_duplicate_scale"
    bl_label = "Convert Duplicate Scale"
    bl_description = "Normalize Armature_Astro scale inside Astro_Converted while preserving child mesh world transforms"

    converted_collection_name: bpy.props.StringProperty(
        name="Converted Collection",
        default="Astro_Converted",
    )

    duplicate_armature_name: bpy.props.StringProperty(
        name="Duplicate Armature",
        default="Armature_Astro",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        lines = ["========== ASTRO MOBA CONVERT DUPLICATE SCALE ==========", ""]

        collection = bpy.data.collections.get(self.converted_collection_name)
        if not collection:
            lines.append(f"ERROR: Collection not found: {self.converted_collection_name}")
            write_text_report("ASTRO_CONVERT_SCALE_REPORT", lines)
            self.report({"ERROR"}, "Converted collection not found")
            return {"CANCELLED"}

        arm = bpy.data.objects.get(self.duplicate_armature_name)
        if not arm or arm.type != "ARMATURE":
            lines.append(f"ERROR: Duplicate armature not found: {self.duplicate_armature_name}")
            write_text_report("ASTRO_CONVERT_SCALE_REPORT", lines)
            self.report({"ERROR"}, "Duplicate armature not found")
            return {"CANCELLED"}

        # Only operate on mesh descendants inside the converted duplicate set.
        converted_objects = set(collection.objects)
        mesh_descendants = [
            obj for obj in converted_objects
            if obj.type == "MESH" and is_descendant_of(obj, arm)
        ]

        old_scale = arm.scale.copy()
        old_matrix_world = arm.matrix_world.copy()

        # Store world matrices so visual positions survive armature scale normalization.
        stored_world = {obj.name: obj.matrix_world.copy() for obj in mesh_descendants}

        # Also store modifier targets for reporting.
        skinned = []
        rigid = []
        for obj in mesh_descendants:
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)
            if has_arm_mod:
                skinned.append(obj.name)
            else:
                rigid.append(obj.name)

        # Normalize the duplicate armature object scale.
        # This does not alter source armature or source meshes.
        arm.scale = (1.0, 1.0, 1.0)
        bpy.context.view_layer.update()

        # Restore mesh world matrices, then recalculate parent inverses so children remain visually placed.
        for obj in mesh_descendants:
            obj.matrix_world = stored_world[obj.name]
            if obj.parent:
                obj.matrix_parent_inverse = obj.parent.matrix_world.inverted() @ obj.matrix_world

        bpy.context.view_layer.update()

        lines.append(f"Collection: {collection.name}")
        lines.append(f"Armature: {arm.name}")
        lines.append(f"Old armature scale: {tuple(round(v, 5) for v in old_scale)}")
        lines.append(f"New armature scale: {tuple(round(v, 5) for v in arm.scale)}")
        lines.append("")
        lines.append(f"Meshes preserved in world space: {len(mesh_descendants)}")
        for obj in mesh_descendants:
            lines.append(f"  - {obj.name}")
        lines.append("")
        lines.append(f"Skinned meshes: {len(skinned)}")
        for name in skinned:
            lines.append(f"  - {name}")
        lines.append("")
        lines.append(f"Rigid/accessory meshes: {len(rigid)}")
        for name in rigid:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append("Important:")
        lines.append("  This operation only modified the duplicate conversion collection.")
        lines.append("  Original source objects were not modified.")
        lines.append("  If the duplicate looks wrong, delete Astro_Converted and run Prepare Conversion again.")
        lines.append("")
        lines.append("Next check:")
        lines.append("  Run Analyze Character or inspect Armature_Astro scale.")
        lines.append("  Then try manual GLB export from the converted duplicate.")
        lines.append("")
        lines.append("========== END CONVERT DUPLICATE SCALE ==========")

        write_text_report("ASTRO_CONVERT_SCALE_REPORT", lines)
        self.report({"INFO"}, "Converted duplicate armature scale to 1,1,1")
        return {"FINISHED"}



class ASTRO_OT_rebuild_astro_rig(bpy.types.Operator):
    bl_idname = "astro_moba.rebuild_astro_rig"
    bl_label = "Experimental Rebuild Rig"
    bl_description = "Experimental: creates a fresh unit-scale armature. Do not use as final conversion yet."

    rebuilt_collection_name: bpy.props.StringProperty(
        name="Rebuilt Collection",
        default="Astro_Rebuilt",
    )

    new_armature_name: bpy.props.StringProperty(
        name="New Armature",
        default="Armature_AstroClean",
    )

    ignore_names: bpy.props.StringProperty(
        name="Ignore Objects",
        default="Plane.013",
        description="Comma-separated object names to exclude from rebuild",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        source_arm = get_armature()
        lines = ["========== ASTRO MOBA REBUILD ASTRO RIG ==========", ""]

        if not source_arm or source_arm.type != "ARMATURE":
            lines.append("ERROR: No source armature found.")
            write_text_report("ASTRO_REBUILD_RIG_REPORT", lines)
            self.report({"ERROR"}, "No source armature found")
            return {"CANCELLED"}

        ignore_set = {name.strip() for name in self.ignore_names.split(",") if name.strip()}

        # Gather source meshes descended from the source armature.
        source_meshes = []
        ignored = []
        for obj in bpy.data.objects:
            if obj.type != "MESH":
                continue
            if not is_descendant_of(obj, source_arm):
                continue
            if obj.name in ignore_set:
                ignored.append(obj.name)
                continue
            source_meshes.append(obj)

        # Remove existing rebuild collection if present.
        existing = bpy.data.collections.get(self.rebuilt_collection_name)
        if existing:
            for obj in list(existing.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(existing)

        rebuilt_collection = bpy.data.collections.new(self.rebuilt_collection_name)
        bpy.context.scene.collection.children.link(rebuilt_collection)

        # Create new clean armature at identity transform.
        arm_data = bpy.data.armatures.new(self.new_armature_name + "_Data")
        clean_arm = bpy.data.objects.new(self.new_armature_name, arm_data)
        rebuilt_collection.objects.link(clean_arm)
        clean_arm.location = (0, 0, 0)
        clean_arm.rotation_euler = (0, 0, 0)
        clean_arm.scale = (1, 1, 1)

        # Build bones from source rest pose, converted into world-space coordinates.
        bpy.context.view_layer.objects.active = clean_arm
        clean_arm.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")

        # Remove default bones if any exist.
        for bone in list(arm_data.edit_bones):
            arm_data.edit_bones.remove(bone)

        source_bone_names = []
        source_local_by_name = {}

        for src_bone in source_arm.data.bones:
            source_bone_names.append(src_bone.name)
            source_local_by_name[src_bone.name] = src_bone

            new_bone = arm_data.edit_bones.new(src_bone.name)

            # Convert source armature-local bone coordinates through the source object transform.
            # This bakes the legacy 0.01 object scale into the clean armature rest position.
            new_bone.head = source_arm.matrix_world @ src_bone.head_local
            new_bone.tail = source_arm.matrix_world @ src_bone.tail_local

            # Blender 5.x does not expose roll on regular Bone objects.
            # For this first clean rebuild, preserve head/tail and deform state.
            # Bone roll/orientation calibration can be added later using EditBone tools.
            new_bone.use_deform = src_bone.use_deform

        # Restore parent relationships.
        for src_bone in source_arm.data.bones:
            if src_bone.parent:
                child = arm_data.edit_bones.get(src_bone.name)
                parent = arm_data.edit_bones.get(src_bone.parent.name)
                if child and parent:
                    child.parent = parent
                    child.use_connect = src_bone.use_connect

        bpy.ops.object.mode_set(mode="OBJECT")

        # Duplicate source meshes and preserve world matrices.
        mesh_map = {}
        copied = []
        skinned = []
        rigid = []

        for src_obj in source_meshes:
            src_world = src_obj.matrix_world.copy()

            obj_copy = src_obj.copy()
            obj_copy.data = src_obj.data.copy()
            obj_copy.animation_data_clear()
            obj_copy.name = src_obj.name + "_Rebuilt"
            obj_copy.data.name = src_obj.data.name + "_Rebuilt"
            rebuilt_collection.objects.link(obj_copy)

            # Retarget armature modifiers to clean armature.
            has_arm_mod = False
            for mod in obj_copy.modifiers:
                if mod.type == "ARMATURE" and mod.object == source_arm:
                    mod.object = clean_arm
                    has_arm_mod = True

            if has_arm_mod:
                skinned.append(obj_copy.name)
            else:
                rigid.append(obj_copy.name)

            # Parent everything under the clean armature for a predictable export hierarchy.
            obj_copy.parent = clean_arm
            obj_copy.matrix_world = src_world
            obj_copy.matrix_parent_inverse = clean_arm.matrix_world.inverted() @ obj_copy.matrix_world

            mesh_map[src_obj.name] = obj_copy
            copied.append(f"{src_obj.name} -> {obj_copy.name}")

        bpy.context.view_layer.update()

        # Basic validation data.
        lines.append(f"Source armature: {source_arm.name}")
        lines.append(f"Source armature scale: {tuple(round(v, 5) for v in source_arm.scale)}")
        lines.append(f"New armature: {clean_arm.name}")
        lines.append(f"New armature scale: {tuple(round(v, 5) for v in clean_arm.scale)}")
        lines.append(f"Created collection: {rebuilt_collection.name}")
        lines.append("")
        lines.append(f"Rebuilt bones: {len(source_bone_names)}")
        for name in source_bone_names:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append("Ignored source objects:")
        if ignored:
            for name in ignored:
                lines.append(f"  - {name}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append(f"Copied meshes: {len(copied)}")
        for item in copied:
            lines.append(f"  - {item}")

        lines.append("")
        lines.append(f"Skinned rebuilt meshes: {len(skinned)}")
        for name in skinned:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append(f"Rigid rebuilt meshes: {len(rigid)}")
        for name in rigid:
            lines.append(f"  - {name}")

        lines.append("")
        lines.append("Important:")
        lines.append("  Source objects were not modified.")
        lines.append("  This creates a clean unit-scale armature from the source rest pose.")
        lines.append("  Meshes are duplicated and parented under the clean armature.")
        lines.append("  Skinned mesh modifiers are retargeted to the clean armature.")
        lines.append("")
        lines.append("Next check:")
        lines.append("  Inspect Astro_Rebuilt visually.")
        lines.append("  Run Analyze Character.")
        lines.append("  Try generating a simple pose/animation on Armature_AstroClean.")
        lines.append("")
        lines.append("========== END REBUILD ASTRO RIG ==========")

        write_text_report("ASTRO_REBUILD_RIG_REPORT", lines)
        self.report({"INFO"}, f"Rebuilt clean rig: {clean_arm.name}")
        return {"FINISHED"}



class ASTRO_OT_bind_pose_inspector(bpy.types.Operator):
    bl_idname = "astro_moba.bind_pose_inspector"
    bl_label = "Bind Pose Inspector"
    bl_description = "Inspect skinned meshes, rigid accessories, parent relationships, bind-related data, and legacy Unity risk factors"

    def execute(self, context):
        arm = get_armature()
        lines = ["========== ASTRO MOBA BIND POSE / SKIN INSPECTOR ==========", ""]

        if not arm or arm.type != "ARMATURE":
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_BIND_POSE_INSPECTOR", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        lines.append(f"Armature: {arm.name}")
        lines.append(f"Armature object scale: {tuple(round(v, 5) for v in arm.scale)}")
        lines.append(f"Armature object location: {tuple(round(v, 5) for v in arm.location)}")
        lines.append(f"Bone count: {len(arm.data.bones)}")
        lines.append("")

        mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH" and is_descendant_of(obj, arm)]

        skinned = []
        rigid = []
        suspicious = []

        for obj in mesh_objects:
            armature_mods = [mod for mod in obj.modifiers if mod.type == "ARMATURE"]
            targets_this_arm = [mod for mod in armature_mods if mod.object == arm]
            has_vertex_groups = len(obj.vertex_groups) > 0

            if targets_this_arm:
                skinned.append(obj)
            else:
                rigid.append(obj)

            if has_vertex_groups and not targets_this_arm:
                suspicious.append((obj.name, "Has vertex groups but no Armature modifier targeting this armature"))
            if targets_this_arm and not has_vertex_groups:
                suspicious.append((obj.name, "Has Armature modifier but no vertex groups"))
            if tuple(round(v, 5) for v in obj.scale) != (1.0, 1.0, 1.0):
                suspicious.append((obj.name, f"Non-unit object scale {tuple(round(v, 5) for v in obj.scale)}"))

        lines.append("SUMMARY")
        lines.append(f"Meshes under armature: {len(mesh_objects)}")
        lines.append(f"Skinned meshes: {len(skinned)}")
        lines.append(f"Rigid/accessory meshes: {len(rigid)}")
        lines.append(f"Suspicious mesh conditions: {len(suspicious)}")
        lines.append("")

        lines.append("SKINNED MESHES")
        if not skinned:
            lines.append("  None")
        for obj in skinned:
            lines.append(f"- {obj.name}")
            lines.append(f"    Parent: {obj.parent.name if obj.parent else 'None'}")
            lines.append(f"    Mesh data: {obj.data.name}")
            lines.append(f"    Vertices: {len(obj.data.vertices)}")
            lines.append(f"    Polygons: {len(obj.data.polygons)}")
            lines.append(f"    Object scale: {tuple(round(v, 5) for v in obj.scale)}")
            lines.append(f"    Dimensions: {tuple(round(v, 5) for v in obj.dimensions)}")
            lines.append(f"    Vertex groups: {len(obj.vertex_groups)}")

            armature_mods = [mod for mod in obj.modifiers if mod.type == "ARMATURE"]
            for mod in armature_mods:
                lines.append(f"    Armature modifier: {mod.name}")
                lines.append(f"      Target: {mod.object.name if mod.object else 'None'}")
                lines.append(f"      Show viewport: {mod.show_viewport}")
                lines.append(f"      Show render: {mod.show_render}")

            group_names = [vg.name for vg in obj.vertex_groups]
            matching_groups = [name for name in group_names if arm.data.bones.get(name)]
            missing_bone_groups = [name for name in group_names if not arm.data.bones.get(name)]
            bones_without_groups = [bone.name for bone in arm.data.bones if bone.use_deform and bone.name not in group_names]

            lines.append(f"    Vertex groups matching bones: {len(matching_groups)}")
            if matching_groups:
                lines.append(f"      First matches: {', '.join(matching_groups[:20])}")

            lines.append(f"    Vertex groups with no matching bone: {len(missing_bone_groups)}")
            if missing_bone_groups:
                lines.append(f"      {', '.join(missing_bone_groups[:20])}")

            lines.append(f"    Deform bones with no vertex group on this mesh: {len(bones_without_groups)}")
            if bones_without_groups:
                lines.append(f"      First missing: {', '.join(bones_without_groups[:20])}")
            lines.append("")

        lines.append("RIGID / ACCESSORY MESHES")
        if not rigid:
            lines.append("  None")
        for obj in rigid:
            lines.append(f"- {obj.name}")
            lines.append(f"    Parent: {obj.parent.name if obj.parent else 'None'}")
            lines.append(f"    Mesh data: {obj.data.name}")
            lines.append(f"    Vertices: {len(obj.data.vertices)}")
            lines.append(f"    Polygons: {len(obj.data.polygons)}")
            lines.append(f"    Object location: {tuple(round(v, 5) for v in obj.location)}")
            lines.append(f"    Object scale: {tuple(round(v, 5) for v in obj.scale)}")
            lines.append(f"    Dimensions: {tuple(round(v, 5) for v in obj.dimensions)}")
            lines.append(f"    Vertex groups: {len(obj.vertex_groups)}")
            lines.append("")

        lines.append("BIND / REST POSE SNAPSHOT")
        lines.append("This section records rest-bone dimensions and parent relationships.")
        for bone in arm.data.bones:
            parent_name = bone.parent.name if bone.parent else "None"
            length = bone.length
            lines.append(f"- {bone.name} | parent: {parent_name} | deform: {bone.use_deform} | length: {round(length, 5)}")
        lines.append("")

        lines.append("SUSPICIOUS CONDITIONS")
        if not suspicious:
            lines.append("  None")
        for name, reason in suspicious:
            lines.append(f"  - {name}: {reason}")
        lines.append("")

        lines.append("LEGACY UNITY RISK ASSESSMENT")
        risk = 0
        notes = []

        if tuple(round(v, 5) for v in arm.scale) != (1.0, 1.0, 1.0):
            risk += 35
            notes.append("Armature has non-unit scale. This is common in Unity/FBX imports and risky for GLB export.")

        if rigid:
            risk += 25
            notes.append("Rigid child/accessory meshes exist. These need special handling before scale conversion.")

        broken_images = []
        for image in bpy.data.images:
            if image.name in {"Render Result", "Viewer Node"}:
                continue
            if image.size[0] == 0 or image.size[1] == 0:
                broken_images.append(image.name)

        if broken_images:
            risk += 20
            notes.append(f"Broken image references detected: {', '.join(broken_images[:10])}")

        if not skinned:
            risk += 30
            notes.append("No skinned meshes found.")

        if risk > 100:
            risk = 100

        lines.append(f"Estimated legacy conversion risk: {risk}/100")
        if notes:
            for note in notes:
                lines.append(f"  - {note}")
        else:
            lines.append("  No major legacy risks detected.")
        lines.append("")

        lines.append("RECOMMENDED PATH")
        lines.append("  1. Preserve the original armature/rest pose for skinned meshes.")
        lines.append("  2. Do not rebuild or rescale skinned bind data until we can preserve bind matrices.")
        lines.append("  3. Convert rigid accessory meshes separately, using bone/socket parenting.")
        lines.append("  4. Fix or replace broken texture references.")
        lines.append("  5. Export a cleaned hierarchy while preserving the existing valid skinning.")
        lines.append("")
        lines.append("========== END BIND POSE / SKIN INSPECTOR ==========")

        write_text_report("ASTRO_BIND_POSE_INSPECTOR", lines)
        self.report({"INFO"}, "Bind pose inspector report created")
        return {"FINISHED"}



class ASTRO_OT_map_rigid_accessories(bpy.types.Operator):
    bl_idname = "astro_moba.map_rigid_accessories"
    bl_label = "Map Rigid Accessories"
    bl_description = "Classify rigid/accessory meshes using names plus vertex-sampling nearest-bone histograms"

    max_sample_vertices: bpy.props.IntProperty(
        name="Max Sample Vertices",
        default=250,
        min=25,
        max=5000,
        description="Maximum vertices sampled per rigid mesh for nearest-bone histogram"
    )

    def execute(self, context):
        import mathutils

        arm = get_armature()
        lines = ["========== ASTRO MOBA RIGID ACCESSORY MAP ==========", ""]

        if not arm or arm.type != "ARMATURE":
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_RIGID_ACCESSORY_MAP", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH" and is_descendant_of(obj, arm)]

        rigid = []
        skinned = []

        for obj in mesh_objects:
            has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)
            if has_arm_mod:
                skinned.append(obj)
            else:
                rigid.append(obj)

        socket_names = {bone.name for bone in arm.data.bones if "Socket" in bone.name}
        bone_names = {bone.name for bone in arm.data.bones}

        preferred_body_bones = [
            "Head", "Neck", "Ribcage", "Spine2", "Pelvis",
            "LUpperarm", "LForearm", "LPalm",
            "RUpperarm", "RForearm", "RPalm",
            "LThigh", "LCalf", "LFoot",
            "RThigh", "RCalf", "RFoot",
        ]

        preferred_socket_bones = [
            "HeadSocket", "ChestSocket", "BackpackSocket",
            "BeltSocket_L", "BeltSocket_R",
        ]

        # Vertex histogram uses body/deform bones first, not equipment sockets.
        # Sockets are semantically useful, but they can sit near the centre of unrelated objects.
        histogram_candidate_bones = [
            bone for bone in arm.data.bones
            if bone.name in preferred_body_bones
        ]

        socket_candidate_bones = [
            bone for bone in arm.data.bones
            if bone.name in preferred_socket_bones
        ]

        def bone_segment_distance(point, bone):
            head = arm.matrix_world @ bone.head_local
            tail = arm.matrix_world @ bone.tail_local
            segment = tail - head
            seg_len_sq = segment.length_squared

            if seg_len_sq == 0:
                return (point - head).length

            t = max(0.0, min(1.0, (point - head).dot(segment) / seg_len_sq))
            closest = head + segment * t
            return (point - closest).length

        def vertex_histogram_for_object(obj):
            verts = obj.data.vertices
            total = len(verts)

            if total == 0 or not histogram_candidate_bones:
                return [], 0, 0.0

            sample_target = min(self.max_sample_vertices, total)

            if sample_target <= 0:
                return [], 0, 0.0, 0.0

            # Blender 5.1 bpy_prop_collection does not support slicing.
            # Build evenly distributed sample indices manually.
            if sample_target == total:
                indices = range(total)
                step_size = 1.0
            else:
                step_size = total / float(sample_target)
                indices = [min(total - 1, int(i * step_size)) for i in range(sample_target)]

            sampled = [verts[i] for i in indices]

            counts = {bone.name: 0 for bone in histogram_candidate_bones}
            distances = {bone.name: 0.0 for bone in histogram_candidate_bones}

            for vert in sampled:
                world_point = obj.matrix_world @ vert.co

                best_bone = None
                best_dist = None

                for bone in histogram_candidate_bones:
                    dist = bone_segment_distance(world_point, bone)
                    if best_dist is None or dist < best_dist:
                        best_dist = dist
                        best_bone = bone.name

                if best_bone:
                    counts[best_bone] += 1
                    distances[best_bone] += best_dist if best_dist is not None else 0.0

            ranked = []
            sample_count = len(sampled)

            for bone_name, count in counts.items():
                if count <= 0:
                    continue
                percent = (count / sample_count) * 100.0 if sample_count else 0.0
                avg_dist = distances[bone_name] / count if count else 0.0
                ranked.append((bone_name, count, percent, avg_dist))

            ranked.sort(key=lambda item: (-item[1], item[3]))
            return ranked, sample_count, step_size

        def object_world_center(obj):
            corners = [obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box]
            return sum(corners, mathutils.Vector()) / 8.0

        def nearest_socket_for_object(obj, allowed_sockets=None):
            if allowed_sockets is None:
                allowed_sockets = preferred_socket_bones

            center = object_world_center(obj)
            candidates = [bone for bone in socket_candidate_bones if bone.name in allowed_sockets]

            if not candidates:
                return None, None

            results = []
            for bone in candidates:
                dist = bone_segment_distance(center, bone)
                results.append((bone.name, dist))

            results.sort(key=lambda item: item[1])
            return results[0]

        def name_based_target(obj_name):
            lower = obj_name.lower()

            if "rifle" in lower or "gun" in lower or "weapon" in lower:
                return "WeaponSocket", "Equipment weapon detected by name", "EQUIPMENT"

            if "helmet" in lower or "head" in lower:
                if "HeadSocket" in socket_names:
                    return "HeadSocket", "Headwear detected by name", "HEADWEAR"
                return "Head", "Headwear detected by name; no HeadSocket found", "HEADWEAR"

            if "jet" in lower or "pack" in lower or "back" in lower:
                if "BackpackSocket" in socket_names:
                    return "BackpackSocket", "Back/backpack item detected by name", "BACK"
                return "Spine2", "Back/backpack item detected by name; no BackpackSocket found", "BACK"

            if "suit" in lower or "chest" in lower or "torso" in lower:
                return "Ribcage", "Torso/body armour detected by name", "TORSO"

            if ("arm_02_l" in lower) or ("arm_l" in lower) or ("arm" in lower and "_l" in lower):
                return "LForearm", "Left arm accessory detected by name", "L_ARM"

            if ("arm_02_r" in lower) or ("arm_r" in lower) or ("arm" in lower and "_r" in lower):
                return "RForearm", "Right arm accessory detected by name", "R_ARM"

            if ("leg_02_l" in lower) or ("leg_l" in lower) or ("leg" in lower and "_l" in lower):
                return "LCalf", "Left leg accessory detected by name", "L_LEG"

            if ("leg_02_r" in lower) or ("leg_r" in lower) or ("leg" in lower and "_r" in lower):
                return "RCalf", "Right leg accessory detected by name", "R_LEG"

            if "belt" in lower:
                if "BeltSocket_L" in socket_names:
                    return "BeltSocket_L", "Belt accessory detected by name", "BELT"
                return "Pelvis", "Belt accessory detected by name; no BeltSocket found", "BELT"

            return "MANUAL_REVIEW", "No confident name-based mapping rule matched", "UNKNOWN"

        def region_for_bone(bone_name):
            groups = {
                "HEAD": {"Head", "Neck", "HeadSocket"},
                "TORSO": {"Ribcage", "Spine2", "ChestSocket", "BackpackSocket"},
                "L_ARM": {"LUpperarm", "LForearm", "LPalm"},
                "R_ARM": {"RUpperarm", "RForearm", "RPalm"},
                "L_LEG": {"LThigh", "LCalf", "LFoot"},
                "R_LEG": {"RThigh", "RCalf", "RFoot"},
                "PELVIS": {"Pelvis", "BeltSocket_L", "BeltSocket_R"},
                "EQUIPMENT": {"WeaponSocket", "LeftWeaponSocket", "ShieldSocket"},
            }

            for region, names in groups.items():
                if bone_name in names:
                    return region

            return "UNKNOWN"

        def final_recommendation(obj, name_target, name_kind, ranked_histogram, sample_count):
            # Equipment is semantic; do not allow geometry to override long weapon placement.
            if name_kind == "EQUIPMENT":
                return name_target, "Very High", "Equipment detected by name; using equipment socket without geometry override."

            hist_target = ranked_histogram[0][0] if ranked_histogram else "NONE"
            hist_percent = ranked_histogram[0][2] if ranked_histogram else 0.0

            if name_target == "MANUAL_REVIEW":
                if hist_target != "NONE" and hist_percent >= 45.0:
                    return hist_target, "Medium", f"No name match; vertex histogram favours {hist_target} at {hist_percent:.1f}%."
                return "MANUAL_REVIEW", "Review", "No name match and no dominant vertex-histogram target."

            if hist_target == "NONE":
                return name_target, "Medium", "Name-based target exists, but histogram had no usable vertex samples."

            if name_target == hist_target:
                return name_target, "Very High", f"Name-based target and vertex histogram agree at {hist_percent:.1f}%."

            name_region = region_for_bone(name_target)
            hist_region = region_for_bone(hist_target)

            if name_region == hist_region and hist_region != "UNKNOWN":
                return name_target, "High", f"Name target and histogram target are in same region: {hist_target} at {hist_percent:.1f}%."

            # Socket compatibility rules.
            socket_equivalence = {
                "HeadSocket": {"Head", "Neck"},
                "BackpackSocket": {"Spine2", "Ribcage"},
                "ChestSocket": {"Ribcage", "Spine2"},
                "BeltSocket_L": {"Pelvis"},
                "BeltSocket_R": {"Pelvis"},
            }

            if name_target in socket_equivalence and hist_target in socket_equivalence[name_target]:
                return name_target, "High", f"Socket target {name_target} is compatible with histogram body target {hist_target}."

            # If histogram is extremely dominant, flag review but show histogram as alternate.
            if hist_percent >= 70.0:
                return name_target, "Review", f"Strong histogram disagreement: {hist_target} at {hist_percent:.1f}%."

            return name_target, "Review", f"Name target {name_target} disagrees with histogram target {hist_target} at {hist_percent:.1f}%."

        lines.append(f"Armature: {arm.name}")
        lines.append(f"Rigid/accessory meshes found: {len(rigid)}")
        lines.append(f"Skinned meshes ignored for accessory mapping: {len(skinned)}")
        lines.append(f"Max sample vertices per mesh: {self.max_sample_vertices}")
        lines.append("")

        lines.append("Suggested Rigid Accessory Mapping:")
        if not rigid:
            lines.append("  None")
        else:
            for obj in rigid:
                name_target, name_reason, name_kind = name_based_target(obj.name)
                ranked_histogram, sample_count, step_size = vertex_histogram_for_object(obj)
                final_target, confidence, final_reason = final_recommendation(
                    obj,
                    name_target,
                    name_kind,
                    ranked_histogram,
                    sample_count
                )

                name_target_exists = name_target in bone_names if name_target != "MANUAL_REVIEW" else False
                final_target_exists = final_target in bone_names if final_target != "MANUAL_REVIEW" else False

                lines.append(f"- {obj.name}")
                lines.append(f"    Final suggested target: {final_target}")
                lines.append(f"    Final target exists: {final_target_exists}")
                lines.append(f"    Confidence: {confidence}")
                lines.append(f"    Decision reason: {final_reason}")
                lines.append("")
                lines.append(f"    Name-based target: {name_target}")
                lines.append(f"    Name target exists: {name_target_exists}")
                lines.append(f"    Name reason: {name_reason}")
                lines.append(f"    Name category: {name_kind}")
                lines.append("")
                lines.append(f"    Mesh vertices: {len(obj.data.vertices)}")
                lines.append(f"    Vertex samples used: {sample_count}")
                lines.append(f"    Approx sample step: {step_size:.3f}")
                lines.append("    Vertex-histogram bone candidates:")
                if ranked_histogram:
                    for bone_name, count, percent, avg_dist in ranked_histogram[:8]:
                        lines.append(f"      - {bone_name}: {count} verts ({percent:.1f}%), avg distance {avg_dist:.5f}")
                else:
                    lines.append("      None")
                lines.append("")
                lines.append(f"    Current parent: {obj.parent.name if obj.parent else 'None'}")
                lines.append(f"    Object scale: {tuple(round(v, 5) for v in obj.scale)}")
                lines.append(f"    Dimensions: {tuple(round(v, 5) for v in obj.dimensions)}")
                lines.append("")

        lines.append("Available Socket Bones:")
        if socket_names:
            for name in sorted(socket_names):
                lines.append(f"  - {name}")
        else:
            lines.append("  None")
        lines.append("")

        lines.append("Available Candidate Body Bones:")
        for name in preferred_body_bones:
            lines.append(f"  {'OK' if name in bone_names else 'MISSING'} - {name}")

        lines.append("")
        lines.append("Important:")
        lines.append("  This is a report only. It does not modify parenting yet.")
        lines.append("  Vertex-histogram analysis samples mesh vertices instead of using one bounding-box centre.")
        lines.append("  Equipment such as rifles bypasses geometry override and uses the equipment socket.")
        lines.append("  Next build can create a preview duplicate using only High / Very High mappings.")
        lines.append("")
        lines.append("========== END RIGID ACCESSORY MAP ==========")

        write_text_report("ASTRO_RIGID_ACCESSORY_MAP", lines)
        self.report({"INFO"}, "Vertex-histogram rigid accessory map created")
        return {"FINISHED"}


def astro_compute_rigid_mapping(arm, max_sample_vertices=250):
    """
    Returns mapping data for rigid/accessory meshes under armature.
    This mirrors the report logic used by Map Rigid Accessories, but returns data for preview conversion.
    """
    import mathutils

    mesh_objects = [obj for obj in bpy.data.objects if obj.type == "MESH" and is_descendant_of(obj, arm)]

    rigid = []
    for obj in mesh_objects:
        has_arm_mod = any(mod.type == "ARMATURE" and mod.object == arm for mod in obj.modifiers)
        if not has_arm_mod:
            rigid.append(obj)

    socket_names = {bone.name for bone in arm.data.bones if "Socket" in bone.name}
    bone_names = {bone.name for bone in arm.data.bones}

    preferred_body_bones = [
        "Head", "Neck", "Ribcage", "Spine2", "Pelvis",
        "LUpperarm", "LForearm", "LPalm",
        "RUpperarm", "RForearm", "RPalm",
        "LThigh", "LCalf", "LFoot",
        "RThigh", "RCalf", "RFoot",
    ]

    histogram_candidate_bones = [
        bone for bone in arm.data.bones
        if bone.name in preferred_body_bones
    ]

    def bone_segment_distance(point, bone):
        head = arm.matrix_world @ bone.head_local
        tail = arm.matrix_world @ bone.tail_local
        segment = tail - head
        seg_len_sq = segment.length_squared

        if seg_len_sq == 0:
            return (point - head).length

        t = max(0.0, min(1.0, (point - head).dot(segment) / seg_len_sq))
        closest = head + segment * t
        return (point - closest).length

    def vertex_histogram_for_object(obj):
        verts = obj.data.vertices
        total = len(verts)

        if total == 0 or not histogram_candidate_bones:
            return [], 0, 0.0

        sample_target = min(max_sample_vertices, total)

        if sample_target <= 0:
            return [], 0, 0.0

        if sample_target == total:
            indices = range(total)
            step_size = 1.0
        else:
            step_size = total / float(sample_target)
            indices = [min(total - 1, int(i * step_size)) for i in range(sample_target)]

        sampled = [verts[i] for i in indices]

        counts = {bone.name: 0 for bone in histogram_candidate_bones}
        distances = {bone.name: 0.0 for bone in histogram_candidate_bones}

        for vert in sampled:
            world_point = obj.matrix_world @ vert.co

            best_bone = None
            best_dist = None

            for bone in histogram_candidate_bones:
                dist = bone_segment_distance(world_point, bone)
                if best_dist is None or dist < best_dist:
                    best_dist = dist
                    best_bone = bone.name

            if best_bone:
                counts[best_bone] += 1
                distances[best_bone] += best_dist if best_dist is not None else 0.0

        ranked = []
        sample_count = len(sampled)

        for bone_name, count in counts.items():
            if count <= 0:
                continue
            percent = (count / sample_count) * 100.0 if sample_count else 0.0
            avg_dist = distances[bone_name] / count if count else 0.0
            ranked.append((bone_name, count, percent, avg_dist))

        ranked.sort(key=lambda item: (-item[1], item[3]))
        return ranked, sample_count, step_size

    def name_based_target(obj_name):
        lower = obj_name.lower()

        if "rifle" in lower or "gun" in lower or "weapon" in lower:
            return "WeaponSocket", "Equipment weapon detected by name", "EQUIPMENT"

        if "helmet" in lower or "head" in lower:
            if "HeadSocket" in socket_names:
                return "HeadSocket", "Headwear detected by name", "HEADWEAR"
            return "Head", "Headwear detected by name; no HeadSocket found", "HEADWEAR"

        if "jet" in lower or "pack" in lower or "back" in lower:
            if "BackpackSocket" in socket_names:
                return "BackpackSocket", "Back/backpack item detected by name", "BACK"
            return "Spine2", "Back/backpack item detected by name; no BackpackSocket found", "BACK"

        if "suit" in lower or "chest" in lower or "torso" in lower:
            return "Ribcage", "Torso/body armour detected by name", "TORSO"

        if ("arm_02_l" in lower) or ("arm_l" in lower) or ("arm" in lower and "_l" in lower):
            return "LForearm", "Left arm accessory detected by name", "L_ARM"

        if ("arm_02_r" in lower) or ("arm_r" in lower) or ("arm" in lower and "_r" in lower):
            return "RForearm", "Right arm accessory detected by name", "R_ARM"

        if ("leg_02_l" in lower) or ("leg_l" in lower) or ("leg" in lower and "_l" in lower):
            return "LCalf", "Left leg accessory detected by name", "L_LEG"

        if ("leg_02_r" in lower) or ("leg_r" in lower) or ("leg" in lower and "_r" in lower):
            return "RCalf", "Right leg accessory detected by name", "R_LEG"

        if "belt" in lower:
            if "BeltSocket_L" in socket_names:
                return "BeltSocket_L", "Belt accessory detected by name", "BELT"
            return "Pelvis", "Belt accessory detected by name; no BeltSocket found", "BELT"

        return "MANUAL_REVIEW", "No confident name-based mapping rule matched", "UNKNOWN"

    def region_for_bone(bone_name):
        groups = {
            "HEAD": {"Head", "Neck", "HeadSocket"},
            "TORSO": {"Ribcage", "Spine2", "ChestSocket", "BackpackSocket"},
            "L_ARM": {"LUpperarm", "LForearm", "LPalm"},
            "R_ARM": {"RUpperarm", "RForearm", "RPalm"},
            "L_LEG": {"LThigh", "LCalf", "LFoot"},
            "R_LEG": {"RThigh", "RCalf", "RFoot"},
            "PELVIS": {"Pelvis", "BeltSocket_L", "BeltSocket_R"},
            "EQUIPMENT": {"WeaponSocket", "LeftWeaponSocket", "ShieldSocket"},
        }

        for region, names in groups.items():
            if bone_name in names:
                return region

        return "UNKNOWN"

    def final_recommendation(name_target, name_kind, ranked_histogram):
        if name_kind == "EQUIPMENT":
            return name_target, "Very High", "Equipment detected by name; using equipment socket without geometry override."

        hist_target = ranked_histogram[0][0] if ranked_histogram else "NONE"
        hist_percent = ranked_histogram[0][2] if ranked_histogram else 0.0

        if name_target == "MANUAL_REVIEW":
            if hist_target != "NONE" and hist_percent >= 45.0:
                return hist_target, "Medium", f"No name match; vertex histogram favours {hist_target} at {hist_percent:.1f}%."
            return "MANUAL_REVIEW", "Review", "No name match and no dominant vertex-histogram target."

        if hist_target == "NONE":
            return name_target, "Medium", "Name-based target exists, but histogram had no usable vertex samples."

        if name_target == hist_target:
            return name_target, "Very High", f"Name-based target and vertex histogram agree at {hist_percent:.1f}%."

        name_region = region_for_bone(name_target)
        hist_region = region_for_bone(hist_target)

        if name_region == hist_region and hist_region != "UNKNOWN":
            return name_target, "High", f"Name target and histogram target are in same region: {hist_target} at {hist_percent:.1f}%."

        socket_equivalence = {
            "HeadSocket": {"Head", "Neck"},
            "BackpackSocket": {"Spine2", "Ribcage"},
            "ChestSocket": {"Ribcage", "Spine2"},
            "BeltSocket_L": {"Pelvis"},
            "BeltSocket_R": {"Pelvis"},
        }

        if name_target in socket_equivalence and hist_target in socket_equivalence[name_target]:
            return name_target, "High", f"Socket target {name_target} is compatible with histogram body target {hist_target}."

        if hist_percent >= 70.0:
            return name_target, "Review", f"Strong histogram disagreement: {hist_target} at {hist_percent:.1f}%."

        return name_target, "Review", f"Name target {name_target} disagrees with histogram target {hist_target} at {hist_percent:.1f}%."

    results = []

    for obj in rigid:
        name_target, name_reason, name_kind = name_based_target(obj.name)
        ranked_histogram, sample_count, step_size = vertex_histogram_for_object(obj)
        final_target, confidence, final_reason = final_recommendation(name_target, name_kind, ranked_histogram)

        results.append({
            "object": obj,
            "name": obj.name,
            "name_target": name_target,
            "name_reason": name_reason,
            "name_kind": name_kind,
            "histogram": ranked_histogram,
            "sample_count": sample_count,
            "step_size": step_size,
            "final_target": final_target,
            "confidence": confidence,
            "final_reason": final_reason,
            "target_exists": final_target in bone_names if final_target != "MANUAL_REVIEW" else False,
        })

    return results


class ASTRO_OT_preview_conversion(bpy.types.Operator):
    bl_idname = "astro_moba.preview_conversion"
    bl_label = "Preview Conversion"
    bl_description = "Create an Astro_Preview duplicate and apply only High / Very High rigid accessory mappings"

    preview_collection_name: bpy.props.StringProperty(
        name="Preview Collection",
        default="Astro_Preview",
    )

    include_high: bpy.props.BoolProperty(
        name="Apply High Confidence",
        default=True,
    )

    include_very_high: bpy.props.BoolProperty(
        name="Apply Very High Confidence",
        default=True,
    )

    max_sample_vertices: bpy.props.IntProperty(
        name="Max Sample Vertices",
        default=250,
        min=25,
        max=5000,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        arm = get_armature()
        lines = ["========== ASTRO MOBA PREVIEW CONVERSION ==========", ""]

        if not arm or arm.type != "ARMATURE":
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_PREVIEW_CONVERSION_REPORT", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        mapping = astro_compute_rigid_mapping(arm, self.max_sample_vertices)

        # Remove existing preview collection to keep preview repeatable.
        existing = bpy.data.collections.get(self.preview_collection_name)
        if existing:
            for obj in list(existing.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(existing)

        preview_collection = bpy.data.collections.new(self.preview_collection_name)
        bpy.context.scene.collection.children.link(preview_collection)

        # Gather all mesh descendants and the armature.
        source_meshes = [obj for obj in bpy.data.objects if obj.type == "MESH" and is_descendant_of(obj, arm)]

        # Duplicate armature object/data.
        arm_copy = arm.copy()
        arm_copy.data = arm.data.copy()
        arm_copy.animation_data_clear()
        arm_copy.name = arm.name + "_Preview"
        arm_copy.data.name = arm.data.name + "_Preview"
        preview_collection.objects.link(arm_copy)

        # Duplicate meshes.
        mesh_map = {}
        for src_obj in source_meshes:
            obj_copy = src_obj.copy()
            obj_copy.data = src_obj.data.copy()
            obj_copy.animation_data_clear()
            obj_copy.name = src_obj.name + "_Preview"
            obj_copy.data.name = src_obj.data.name + "_Preview"
            preview_collection.objects.link(obj_copy)
            mesh_map[src_obj.name] = obj_copy

        # Restore original hierarchy inside preview first.
        for src_obj in source_meshes:
            obj_copy = mesh_map[src_obj.name]
            if src_obj.parent == arm:
                obj_copy.parent = arm_copy
                obj_copy.matrix_parent_inverse = src_obj.matrix_parent_inverse.copy()
            elif src_obj.parent and src_obj.parent.name in mesh_map:
                obj_copy.parent = mesh_map[src_obj.parent.name]
                obj_copy.matrix_parent_inverse = src_obj.matrix_parent_inverse.copy()
            else:
                obj_copy.parent = arm_copy

            obj_copy.matrix_world = src_obj.matrix_world.copy()

            for mod in obj_copy.modifiers:
                if mod.type == "ARMATURE" and mod.object == arm:
                    mod.object = arm_copy

        bpy.context.view_layer.update()

        # Apply high-confidence accessory mapping to preview duplicate only.
        applied = []
        skipped = []

        manual_overrides = astro_load_manual_overrides()

        for item in mapping:
            src_name = item["name"]
            confidence = item["confidence"]
            target_name = item["final_target"]
            target_exists = item["target_exists"]
            override_used = False

            if src_name in manual_overrides:
                target_name = manual_overrides[src_name]
                target_exists = target_name in arm_copy.data.bones
                confidence = "Manual Override"
                override_used = True

            should_apply = (
                target_exists and
                (
                    override_used or
                    ((confidence == "Very High" and self.include_very_high) or
                     (confidence == "High" and self.include_high))
                )
            )

            obj_copy = mesh_map.get(src_name)

            if not obj_copy:
                skipped.append((src_name, target_name, confidence, "Preview copy not found"))
                continue

            if not should_apply:
                skipped.append((src_name, target_name, confidence, item["final_reason"]))
                continue

            # Preserve full visual transform while changing parent.
            # Socket bones can have awkward local orientation/roll, so do not try to manually
            # decompose rotation. Store the complete world matrix and restore it after parenting.
            old_world = obj_copy.matrix_world.copy()

            obj_copy.parent = arm_copy
            obj_copy.parent_type = "BONE"
            obj_copy.parent_bone = target_name

            bpy.context.view_layer.update()

            # Restore full world matrix after assigning the bone parent.
            # This is equivalent to Blender's "Parent to Bone - Keep Transform" behaviour.
            obj_copy.matrix_world = old_world

            bpy.context.view_layer.update()

            applied.append((src_name, target_name, confidence, item["final_reason"]))

        bpy.context.view_layer.update()

        lines.append(f"Source armature: {arm.name}")
        lines.append(f"Preview armature: {arm_copy.name}")
        lines.append(f"Preview collection: {preview_collection.name}")
        lines.append("")
        lines.append("Applied mappings:")
        if applied:
            for src_name, target_name, confidence, reason in applied:
                lines.append(f"  - {src_name} -> {target_name} | {confidence} | {reason}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Skipped / Manual review:")
        if skipped:
            for src_name, target_name, confidence, reason in skipped:
                lines.append(f"  - {src_name} -> {target_name} | {confidence} | {reason}")
        else:
            lines.append("  None")

        lines.append("")
        lines.append("Important:")
        lines.append("  The source character was not modified.")
        lines.append("  Only the Astro_Preview duplicate was changed.")
        lines.append("  Review/Medium mappings were left untouched for manual handling.")
        lines.append("  If preview looks wrong, delete Astro_Preview or run Preview Conversion again.")
        lines.append("")
        lines.append("========== END PREVIEW CONVERSION ==========")

        write_text_report("ASTRO_PREVIEW_CONVERSION_REPORT", lines)
        self.report({"INFO"}, "Preview conversion created")
        return {"FINISHED"}


MANUAL_OVERRIDE_TEXT = "ASTRO_MANUAL_MAPPING_OVERRIDES"


def astro_load_manual_overrides():
    import json
    text = bpy.data.texts.get(MANUAL_OVERRIDE_TEXT)
    if not text:
        return {}

    try:
        data = json.loads(text.as_string())
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    return {}


def astro_save_manual_overrides(overrides):
    import json
    text = bpy.data.texts.get(MANUAL_OVERRIDE_TEXT) or bpy.data.texts.new(MANUAL_OVERRIDE_TEXT)
    text.clear()
    text.write(json.dumps(overrides, indent=2, sort_keys=True))


def astro_strip_preview_suffix(name):
    if name.endswith("_Preview"):
        return name[:-8]
    return name


def astro_find_preview_armature(collection_name="Astro_Preview"):
    collection = bpy.data.collections.get(collection_name)
    if not collection:
        return None

    for obj in collection.objects:
        if obj.type == "ARMATURE":
            return obj

    return None


def astro_keep_transform_bone_parent(obj, arm, bone_name):
    old_world = obj.matrix_world.copy()

    obj.parent = arm
    obj.parent_type = "BONE"
    obj.parent_bone = bone_name

    bpy.context.view_layer.update()

    obj.matrix_world = old_world

    bpy.context.view_layer.update()


class ASTRO_OT_apply_manual_mapping(bpy.types.Operator):
    bl_idname = "astro_moba.apply_manual_mapping"
    bl_label = "Apply Manual Mapping"
    bl_description = "Bone-parent the selected Astro_Preview object to the chosen target while preserving transform and storing the override"

    preview_collection_name: bpy.props.StringProperty(
        name="Preview Collection",
        default="Astro_Preview",
    )

    target_bone: bpy.props.StringProperty(
        name="Target Bone/Socket",
        default="BackpackSocket",
    )

    def invoke(self, context, event):
        settings = context.scene.astro_moba_settings
        self.target_bone = settings.manual_mapping_target
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        lines = ["========== ASTRO MOBA APPLY MANUAL MAPPING ==========", ""]

        obj = context.object
        if not obj or obj.type != "MESH":
            lines.append("ERROR: Select a preview mesh object first.")
            write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
            self.report({"ERROR"}, "Select a preview mesh object first")
            return {"CANCELLED"}

        collection = bpy.data.collections.get(self.preview_collection_name)
        if not collection:
            lines.append(f"ERROR: Preview collection not found: {self.preview_collection_name}")
            write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
            self.report({"ERROR"}, "Preview collection not found")
            return {"CANCELLED"}

        if obj.name not in collection.objects:
            # Blender collection membership test by name can be unreliable across versions;
            # fallback to users_collection check.
            if collection not in obj.users_collection:
                lines.append(f"ERROR: Selected object is not in {self.preview_collection_name}: {obj.name}")
                write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
                self.report({"ERROR"}, "Selected object is not in Astro_Preview")
                return {"CANCELLED"}

        arm = astro_find_preview_armature(self.preview_collection_name)
        if not arm:
            lines.append(f"ERROR: No armature found in {self.preview_collection_name}")
            write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
            self.report({"ERROR"}, "No preview armature found")
            return {"CANCELLED"}

        if self.target_bone not in arm.data.bones:
            lines.append(f"ERROR: Target bone/socket not found: {self.target_bone}")
            lines.append("")
            lines.append("Available likely targets:")
            for bone in arm.data.bones:
                if "Socket" in bone.name or bone.name in {
                    "Head", "Neck", "Ribcage", "Spine2", "Pelvis",
                    "LUpperarm", "LForearm", "LPalm",
                    "RUpperarm", "RForearm", "RPalm",
                    "LThigh", "LCalf", "LFoot",
                    "RThigh", "RCalf", "RFoot",
                }:
                    lines.append(f"  - {bone.name}")
            write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
            self.report({"ERROR"}, "Target bone/socket not found")
            return {"CANCELLED"}

        before_parent = obj.parent.name if obj.parent else "None"
        before_parent_type = obj.parent_type
        before_parent_bone = obj.parent_bone

        astro_keep_transform_bone_parent(obj, arm, self.target_bone)

        source_name = astro_strip_preview_suffix(obj.name)
        overrides = astro_load_manual_overrides()
        overrides[source_name] = self.target_bone
        astro_save_manual_overrides(overrides)

        context.scene.astro_moba_settings.manual_mapping_target = self.target_bone

        lines.append(f"Preview object: {obj.name}")
        lines.append(f"Source object key: {source_name}")
        lines.append(f"Preview armature: {arm.name}")
        lines.append(f"Manual target: {self.target_bone}")
        lines.append("")
        lines.append("Previous parent:")
        lines.append(f"  Parent: {before_parent}")
        lines.append(f"  Parent type: {before_parent_type}")
        lines.append(f"  Parent bone: {before_parent_bone}")
        lines.append("")
        lines.append("New parent:")
        lines.append(f"  Parent: {obj.parent.name if obj.parent else 'None'}")
        lines.append(f"  Parent type: {obj.parent_type}")
        lines.append(f"  Parent bone: {obj.parent_bone}")
        lines.append("")
        lines.append("Saved manual overrides:")
        for name, target in sorted(overrides.items()):
            lines.append(f"  - {name} -> {target}")
        lines.append("")
        lines.append("Important:")
        lines.append("  The original source object was not modified.")
        lines.append("  The override is stored in ASTRO_MANUAL_MAPPING_OVERRIDES.")
        lines.append("  Future preview conversions can reuse this override.")
        lines.append("")
        lines.append("========== END APPLY MANUAL MAPPING ==========")

        write_text_report("ASTRO_MANUAL_MAPPING_REPORT", lines)
        self.report({"INFO"}, f"Manual mapping applied: {obj.name} -> {self.target_bone}")
        return {"FINISHED"}


class ASTRO_OT_manual_mapping_report(bpy.types.Operator):
    bl_idname = "astro_moba.manual_mapping_report"
    bl_label = "Manual Mapping Report"
    bl_description = "Show saved manual mapping overrides"

    def execute(self, context):
        overrides = astro_load_manual_overrides()
        lines = ["========== ASTRO MOBA MANUAL MAPPING OVERRIDES ==========", ""]

        if overrides:
            for name, target in sorted(overrides.items()):
                lines.append(f"  - {name} -> {target}")
        else:
            lines.append("No manual overrides saved.")

        lines.append("")
        lines.append("========== END MANUAL MAPPING OVERRIDES ==========")
        write_text_report("ASTRO_MANUAL_MAPPING_OVERRIDES_REPORT", lines)
        self.report({"INFO"}, "Manual mapping report created")
        return {"FINISHED"}

classes = (
    ASTRO_OT_conversion_readiness,
    ASTRO_OT_prepare_conversion,
    ASTRO_OT_convert_duplicate_scale,
    ASTRO_OT_rebuild_astro_rig,
    ASTRO_OT_bind_pose_inspector,
    ASTRO_OT_map_rigid_accessories,
    ASTRO_OT_preview_conversion,
    ASTRO_OT_apply_manual_mapping,
    ASTRO_OT_manual_mapping_report,
)
