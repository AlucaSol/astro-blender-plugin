import bpy
from .constants import REQUIRED_BONES, SOCKETS, STANDARD_RENAME_MAP
from .utils import get_armature, write_text_report

class ASTRO_OT_validate_rig(bpy.types.Operator):
    bl_idname = "astro_moba.validate_rig"
    bl_label = "Validate Rig"
    bl_description = "Check required bones, socket bones, parents, and deform settings"

    def execute(self, context):
        lines = ["========== ASTRO MOBA RIG VALIDATION ==========", ""]
        arm = get_armature()

        if not arm:
            lines.append("ERROR: No armature found.")
            write_text_report("ASTRO_RIG_VALIDATION", lines)
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        lines += [f"Armature: {arm.name}", "", "Required bones:"]
        missing_required = []

        for bone_name in REQUIRED_BONES:
            exists = arm.data.bones.get(bone_name) is not None
            lines.append(f"{'OK' if exists else 'MISSING'} - {bone_name}")
            if not exists:
                missing_required.append(bone_name)

        lines += ["", "Socket bones:"]
        missing_sockets = []
        bad_deform = []
        bad_parent = []

        for socket_name, parent_name, _offset in SOCKETS:
            bone = arm.data.bones.get(socket_name)

            if not bone:
                lines.append(f"MISSING - {socket_name}")
                missing_sockets.append(socket_name)
                continue

            parent = bone.parent.name if bone.parent else "None"
            deform = bone.use_deform
            parent_ok = parent == parent_name
            deform_ok = deform is False
            status = "OK" if parent_ok and deform_ok else "CHECK"
            lines.append(f"{status} - {socket_name} | parent: {parent} | expected parent: {parent_name} | deform: {deform}")

            if not parent_ok:
                bad_parent.append(socket_name)
            if not deform_ok:
                bad_deform.append(socket_name)

        lines.append("")
        if not missing_required and not missing_sockets and not bad_deform and not bad_parent:
            lines.append("RESULT: Rig looks good.")
            report_type = {"INFO"}
            report_msg = "Rig validation passed"
        else:
            lines.append("RESULT: Rig needs attention.")
            if missing_required:
                lines.append(f"Missing required bones: {', '.join(missing_required)}")
            if missing_sockets:
                lines.append(f"Missing sockets: {', '.join(missing_sockets)}")
            if bad_parent:
                lines.append(f"Sockets with wrong parent: {', '.join(bad_parent)}")
            if bad_deform:
                lines.append(f"Sockets with deform enabled: {', '.join(bad_deform)}")
            report_type = {"WARNING"}
            report_msg = "Rig validation found issues"

        lines += ["", "========== END VALIDATION =========="]
        write_text_report("ASTRO_RIG_VALIDATION", lines)
        self.report(report_type, report_msg)
        return {"FINISHED"}

class ASTRO_OT_rename_standard_bones(bpy.types.Operator):
    bl_idname = "astro_moba.rename_standard_bones"
    bl_label = "Rename Standard Bones"
    bl_description = "Rename known original bones to the Astro MOBA standard and update vertex groups"

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        lines = ["========== STANDARD BONE RENAME REPORT ==========", ""]
        bpy.context.view_layer.objects.active = arm
        arm.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")

        renamed_bones = []
        missing_bones = []

        for old_name, new_name in STANDARD_RENAME_MAP.items():
            bone = arm.data.edit_bones.get(old_name)
            if bone:
                bone.name = new_name
                renamed_bones.append(f"{old_name} -> {new_name}")
            else:
                missing_bones.append(old_name)

        bpy.ops.object.mode_set(mode="OBJECT")

        renamed_groups = []
        for obj in bpy.data.objects:
            if obj.type != "MESH":
                continue
            for old_name, new_name in STANDARD_RENAME_MAP.items():
                vg = obj.vertex_groups.get(old_name)
                if vg:
                    vg.name = new_name
                    renamed_groups.append(f"{obj.name}: {old_name} -> {new_name}")

        lines += ["Renamed bones:"]
        lines += [f"OK - {x}" for x in renamed_bones] if renamed_bones else ["None"]
        lines += ["", "Renamed vertex groups:"]
        lines += [f"OK - {x}" for x in renamed_groups] if renamed_groups else ["None"]
        lines += ["", "Original bone names not found:"]
        lines += [f"- {x}" for x in missing_bones] if missing_bones else ["None"]
        lines += ["", "========== END REPORT =========="]

        write_text_report("ASTRO_BONE_RENAME_REPORT", lines)
        self.report({"INFO"}, "Bone rename report created")
        return {"FINISHED"}

classes = (
    ASTRO_OT_validate_rig,
    ASTRO_OT_rename_standard_bones,
)
