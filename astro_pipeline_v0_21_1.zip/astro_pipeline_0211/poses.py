import bpy
import json
from .constants import POSE_TEXT_PREFIX
from .utils import get_armature

def get_saved_pose_items(self, context):
    items = []
    for text in bpy.data.texts:
        if text.name.startswith(POSE_TEXT_PREFIX):
            pose_name = text.name.replace(POSE_TEXT_PREFIX, "", 1)
            items.append((pose_name, pose_name, f"Use saved pose {pose_name}"))

    if not items:
        items.append(("NONE", "No saved poses found", "Create a pose first with Save Current Pose"))

    return items

def apply_saved_pose(arm, pose_text_name):
    text = bpy.data.texts.get(pose_text_name)
    if not text:
        raise Exception(f"Saved pose not found: {pose_text_name}")

    data = json.loads(text.as_string())

    bpy.context.view_layer.objects.active = arm
    arm.select_set(True)
    bpy.ops.object.mode_set(mode="POSE")

    for bone_name, transform in data.get("bones", {}).items():
        pb = arm.pose.bones.get(bone_name)
        if not pb:
            continue
        pb.location = transform["location"]
        pb.rotation_mode = "QUATERNION"
        pb.rotation_quaternion = transform["rotation_quaternion"]
        pb.scale = transform["scale"]

class ASTRO_OT_reset_pose(bpy.types.Operator):
    bl_idname = "astro_moba.reset_pose"
    bl_label = "Reset Pose"
    bl_description = "Clear pose transforms on the armature"

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        bpy.context.view_layer.objects.active = arm
        arm.select_set(True)
        bpy.ops.object.mode_set(mode="POSE")

        for pb in arm.pose.bones:
            pb.location = (0, 0, 0)
            pb.rotation_mode = "QUATERNION"
            pb.rotation_quaternion = (1, 0, 0, 0)
            pb.scale = (1, 1, 1)

        bpy.ops.object.mode_set(mode="OBJECT")
        self.report({"INFO"}, "Pose reset")
        return {"FINISHED"}

class ASTRO_OT_save_current_pose(bpy.types.Operator):
    bl_idname = "astro_moba.save_current_pose"
    bl_label = "Save Current Pose"
    bl_description = "Save the current pose as a JSON text block inside this .blend file"

    pose_name: bpy.props.StringProperty(name="Pose Name", default="RifleReady")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        pose_data = {"armature": arm.name, "bones": {}}

        for pb in arm.pose.bones:
            original_mode = pb.rotation_mode
            pb.rotation_mode = "QUATERNION"
            pose_data["bones"][pb.name] = {
                "location": list(pb.location),
                "rotation_quaternion": list(pb.rotation_quaternion),
                "scale": list(pb.scale),
            }
            pb.rotation_mode = original_mode

        text_name = POSE_TEXT_PREFIX + self.pose_name
        text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
        text.clear()
        text.write(json.dumps(pose_data, indent=2))

        self.report({"INFO"}, f"Saved pose: {text_name}")
        return {"FINISHED"}

class ASTRO_OT_load_pose(bpy.types.Operator):
    bl_idname = "astro_moba.load_pose"
    bl_label = "Load Saved Pose"
    bl_description = "Load a saved pose from an ASTRO_POSE_* text block"

    pose_text_name: bpy.props.StringProperty(name="Pose Text Block", default="ASTRO_POSE_RifleReady")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        arm = get_armature()
        if not arm:
            self.report({"ERROR"}, "No armature found")
            return {"CANCELLED"}

        text = bpy.data.texts.get(self.pose_text_name)
        if not text:
            self.report({"ERROR"}, f"Text block not found: {self.pose_text_name}")
            return {"CANCELLED"}

        apply_saved_pose(arm, self.pose_text_name)
        bpy.ops.object.mode_set(mode="OBJECT")
        self.report({"INFO"}, f"Loaded pose: {self.pose_text_name}")
        return {"FINISHED"}

classes = (
    ASTRO_OT_reset_pose,
    ASTRO_OT_save_current_pose,
    ASTRO_OT_load_pose,
)
